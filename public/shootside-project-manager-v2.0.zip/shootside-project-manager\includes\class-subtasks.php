<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Subtasks {

    public static function format_subtask( $row ) {
        if ( ! $row ) return null;
        $assigned_user = ! empty( $row['assigned_to'] ) ? ShootSide_PM_Auth::format_user( $row['assigned_to'] ) : null;
        $creator = ShootSide_PM_Auth::format_user( $row['created_by'] );

        global $wpdb;
        $comments_table = ShootSide_PM_Database::get_table_name( 'comments' );
        $comments_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$comments_table} WHERE subtask_id = %d AND deleted_at IS NULL", (int) $row['id'] ) );

        return array(
            'id'             => (int) $row['id'],
            'task_id'        => (int) $row['task_id'],
            'title'          => $row['title'],
            'assigned_to_id' => (int) $row['assigned_to'],
            'assigned_to'    => $assigned_user,
            'status'         => $row['status'], // 'todo', 'in_progress', 'completed'
            'due_date'       => $row['due_date'],
            'comments_count' => $comments_count,
            'created_by'     => (int) $row['created_by'],
            'user'           => $creator,
            'created_at'     => $row['created_at'],
            'updated_at'     => $row['updated_at']
        );
    }

    public static function get_for_task( $task_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'subtasks' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE task_id = %d AND deleted_at IS NULL ORDER BY id ASC", (int) $task_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $subtasks = array();
        foreach ( (array) $rows as $row ) {
            $subtasks[] = self::format_subtask( $row );
        }

        return $subtasks;
    }

    public static function get_by_id( $id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'subtasks' );
        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND deleted_at IS NULL", (int) $id );
        $row = $wpdb->get_row( $sql, ARRAY_A );
        return self::format_subtask( $row );
    }

    public static function create( $task_id, $params, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );
        if ( ! $task ) {
            return new WP_Error( 'not_found', 'Parent task not found.', array( 'status' => 404 ) );
        }

        if ( empty( $params['title'] ) ) {
            return new WP_Error( 'missing_title', 'Subtask title is required.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'subtasks' );

        $assigned_to = ! empty( $params['assigned_to_id'] ) ? (int) $params['assigned_to_id'] : ( ! empty( $params['assigned_to'] ) ? (int) $params['assigned_to'] : 0 );
        $status      = ! empty( $params['status'] ) ? sanitize_text_field( $params['status'] ) : 'todo';
        $due_date    = ! empty( $params['due_date'] ) ? sanitize_text_field( $params['due_date'] ) : null;
        $title       = sanitize_text_field( $params['title'] );

        $insert_data = array(
            'task_id'     => (int) $task_id,
            'title'       => $title,
            'assigned_to' => $assigned_to,
            'status'      => $status,
            'due_date'    => $due_date,
            'created_by'  => (int) $current_user->ID,
            'created_at'  => current_time( 'mysql' ),
            'updated_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $subtask_id = $wpdb->insert_id;

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $task_id,
            'subtask_created',
            null,
            $title,
            json_encode( array( 'subtask_id' => $subtask_id, 'assigned_to' => $assigned_to ) )
        );

        // Notify assignee if assigned to someone else
        if ( $assigned_to > 0 && $assigned_to !== (int) $current_user->ID ) {
            ShootSide_PM_Notifications::create(
                $assigned_to,
                'task_assigned',
                'New Subtask Assigned',
                "You were assigned subtask '{$title}' on task: {$task['title']}",
                'task',
                $task_id
            );
        }

        return self::get_by_id( $subtask_id );
    }

    public static function update( $id, $params, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $existing = self::get_by_id( $id );
        if ( ! $existing ) {
            return new WP_Error( 'not_found', 'Subtask not found.', array( 'status' => 404 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'subtasks' );

        $data = array(
            'updated_at' => current_time( 'mysql' )
        );

        if ( isset( $params['title'] ) ) {
            $data['title'] = sanitize_text_field( $params['title'] );
        }

        if ( isset( $params['status'] ) ) {
            $new_status = sanitize_text_field( $params['status'] );
            $data['status'] = $new_status;

            if ( $new_status !== $existing['status'] ) {
                ShootSide_PM_Activity::log(
                    $current_user->ID,
                    'task',
                    $existing['task_id'],
                    'subtask_status_changed',
                    $existing['status'],
                    $new_status,
                    json_encode( array( 'subtask_title' => $existing['title'] ) )
                );
            }
        }

        if ( isset( $params['assigned_to_id'] ) || isset( $params['assigned_to'] ) ) {
            $new_assigned = isset( $params['assigned_to_id'] ) ? (int) $params['assigned_to_id'] : (int) $params['assigned_to'];
            $data['assigned_to'] = $new_assigned;

            if ( $new_assigned !== (int) $existing['assigned_to_id'] ) {
                $old_name = $existing['assigned_to'] ? $existing['assigned_to']['name'] : 'Unassigned';
                $new_user_data = $new_assigned > 0 ? ShootSide_PM_Auth::format_user( $new_assigned ) : null;
                $new_name = $new_user_data ? $new_user_data['name'] : 'Unassigned';

                ShootSide_PM_Activity::log(
                    $current_user->ID,
                    'task',
                    $existing['task_id'],
                    'subtask_reassigned',
                    $old_name,
                    $new_name,
                    json_encode( array( 'subtask_title' => $existing['title'] ) )
                );

                if ( $new_assigned > 0 && $new_assigned !== (int) $current_user->ID ) {
                    ShootSide_PM_Notifications::create(
                        $new_assigned,
                        'task_assigned',
                        'Subtask Assigned to You',
                        "You were assigned subtask: '{$existing['title']}'",
                        'task',
                        $existing['task_id']
                    );
                }
            }
        }

        if ( isset( $params['due_date'] ) ) {
            $data['due_date'] = ! empty( $params['due_date'] ) ? sanitize_text_field( $params['due_date'] ) : null;
        }

        $wpdb->update( $table, $data, array( 'id' => (int) $id ) );

        return self::get_by_id( $id );
    }

    public static function delete( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $existing = self::get_by_id( $id );
        if ( ! $existing ) {
            return new WP_Error( 'not_found', 'Subtask not found.', array( 'status' => 404 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'subtasks' );

        $wpdb->update(
            $table,
            array( 'deleted_at' => current_time( 'mysql' ) ),
            array( 'id' => (int) $id )
        );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $existing['task_id'],
            'subtask_deleted',
            $existing['title'],
            'deleted'
        );

        return true;
    }
}
