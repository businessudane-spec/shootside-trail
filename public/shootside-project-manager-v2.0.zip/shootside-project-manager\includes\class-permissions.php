<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Permissions {

    /**
     * Check if user is an Admin
     */
    public static function is_admin( $user ) {
        if ( ! $user || ! ( $user instanceof WP_User ) ) {
            return false;
        }
        return in_array( 'administrator', (array) $user->roles, true );
    }

    /**
     * Check if user is authenticated (either Admin or Member)
     */
    public static function is_authenticated( $user ) {
        return ( $user && ( $user instanceof WP_User ) && $user->exists() );
    }

    /**
     * Check if user can create projects (Admin only)
     */
    public static function can_create_project( $user ) {
        return self::is_admin( $user );
    }

    /**
     * Check if user can edit/delete projects (Admin only)
     */
    public static function can_manage_project( $user, $project_id ) {
        return self::is_admin( $user );
    }

    /**
     * Check if user can create tasks (Any authenticated user)
     */
    public static function can_create_task( $user ) {
        return self::is_authenticated( $user );
    }

    /**
     * Check if user can edit a task
     * Any authenticated member can edit tasks
     */
    public static function can_edit_task( $user, $task_id ) {
        return self::is_authenticated( $user );
    }

    /**
     * Rule: Can user reassign an EXISTING task?
     * Any authenticated team member can reassign tasks, with full audit logging and notifications.
     */
    public static function can_reassign_task( $user, $existing_task, $new_assigned_to ) {
        return self::is_authenticated( $user );
    }

    /**
     * Check if user can delete/restore items (Admin only)
     */
    public static function can_delete_item( $user ) {
        return self::is_admin( $user );
    }

    public static function can_view_deleted( $user ) {
        return self::is_admin( $user );
    }

    public static function can_restore_item( $user ) {
        return self::is_admin( $user );
    }

    public static function can_view_admin_activity( $user ) {
        return self::is_admin( $user );
    }
}
