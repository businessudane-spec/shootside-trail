<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Vault {

    public static function format_item( $row ) {
        if ( ! $row ) return null;
        $user = ShootSide_PM_Auth::format_user( $row['created_by'] );
        $updater = ! empty( $row['updated_by'] ) ? ShootSide_PM_Auth::format_user( $row['updated_by'] ) : null;

        return array(
            'id'          => (int) $row['id'],
            'title'       => $row['title'],
            'category'    => $row['category'],
            'service_url' => $row['service_url'],
            'username'    => $row['username'],
            'password'    => $row['password'],
            'notes'       => $row['notes'],
            'created_by'  => (int) $row['created_by'],
            'user'        => $user,
            'updated_by'  => (int) $row['updated_by'],
            'updater'     => $updater,
            'created_at'  => $row['created_at'],
            'updated_at'  => $row['updated_at']
        );
    }

    public static function get_all( $args = array(), $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'vault' );

        $where = array( 'deleted_at IS NULL' );
        $params = array();

        if ( ! empty( $args['category'] ) && $args['category'] !== 'All' ) {
            $where[] = 'category = %s';
            $params[] = sanitize_text_field( $args['category'] );
        }

        if ( ! empty( $args['search'] ) ) {
            $like = '%' . $wpdb->esc_like( sanitize_text_field( $args['search'] ) ) . '%';
            $where[] = '(title LIKE %s OR username LIKE %s OR service_url LIKE %s OR notes LIKE %s)';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY title ASC, created_at DESC";

        if ( ! empty( $params ) ) {
            $sql = $wpdb->prepare( $sql, $params );
        }

        $rows = $wpdb->get_results( $sql, ARRAY_A );
        $items = array();
        foreach ( (array) $rows as $row ) {
            $items[] = self::format_item( $row );
        }

        return $items;
    }

    public static function get_by_id( $id, $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'vault' );
        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND deleted_at IS NULL", (int) $id );
        $row = $wpdb->get_row( $sql, ARRAY_A );
        return self::format_item( $row );
    }

    public static function create( $params, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        if ( empty( $params['title'] ) ) {
            return new WP_Error( 'missing_title', 'Title or service name is required.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'vault' );

        $data = array(
            'title'       => sanitize_text_field( $params['title'] ),
            'category'    => ! empty( $params['category'] ) ? sanitize_text_field( $params['category'] ) : 'General',
            'service_url' => ! empty( $params['service_url'] ) ? esc_url_raw( $params['service_url'] ) : '',
            'username'    => ! empty( $params['username'] ) ? sanitize_text_field( $params['username'] ) : '',
            'password'    => ! empty( $params['password'] ) ? $params['password'] : '',
            'notes'       => ! empty( $params['notes'] ) ? sanitize_textarea_field( $params['notes'] ) : '',
            'created_by'  => (int) $current_user->ID,
            'updated_by'  => (int) $current_user->ID,
            'created_at'  => current_time( 'mysql' ),
            'updated_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $data );
        $id = $wpdb->insert_id;

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'vault',
            $id,
            'created_credential',
            null,
            $data['title'],
            json_encode( array( 'category' => $data['category'] ) )
        );

        return self::get_by_id( $id, $current_user );
    }

    public static function update( $id, $params, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $existing = self::get_by_id( $id, $current_user );
        if ( ! $existing ) {
            return new WP_Error( 'not_found', 'Credential not found.', array( 'status' => 404 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'vault' );

        $data = array(
            'updated_by' => (int) $current_user->ID,
            'updated_at' => current_time( 'mysql' )
        );

        if ( isset( $params['title'] ) ) {
            $data['title'] = sanitize_text_field( $params['title'] );
        }
        if ( isset( $params['category'] ) ) {
            $data['category'] = sanitize_text_field( $params['category'] );
        }
        if ( isset( $params['service_url'] ) ) {
            $data['service_url'] = esc_url_raw( $params['service_url'] );
        }
        if ( isset( $params['username'] ) ) {
            $data['username'] = sanitize_text_field( $params['username'] );
        }
        if ( isset( $params['password'] ) ) {
            $data['password'] = $params['password'];
        }
        if ( isset( $params['notes'] ) ) {
            $data['notes'] = sanitize_textarea_field( $params['notes'] );
        }

        $wpdb->update( $table, $data, array( 'id' => (int) $id ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'vault',
            (int) $id,
            'updated_credential',
            $existing['title'],
            $data['title'] ?? $existing['title']
        );

        return self::get_by_id( $id, $current_user );
    }

    public static function delete( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $existing = self::get_by_id( $id, $current_user );
        if ( ! $existing ) {
            return new WP_Error( 'not_found', 'Credential not found.', array( 'status' => 404 ) );
        }

        $is_admin = ShootSide_PM_Permissions::is_admin( $current_user );
        if ( ! $is_admin && (int) $existing['created_by'] !== (int) $current_user->ID ) {
            return new WP_Error( 'forbidden', 'Only Administrators or the creator can delete credentials.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'vault' );

        $wpdb->update(
            $table,
            array(
                'deleted_at' => current_time( 'mysql' ),
                'updated_by' => (int) $current_user->ID
            ),
            array( 'id' => (int) $id )
        );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'vault',
            (int) $id,
            'deleted_credential',
            $existing['title'],
            'deleted'
        );

        return true;
    }
}
