<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Comments {

    public static function get_for_task( $task_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE task_id = %d AND deleted_at IS NULL ORDER BY created_at ASC", (int) $task_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $comments = array();
        foreach ( (array) $rows as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $comments[] = array(
                'id'         => (int) $row['id'],
                'task_id'    => (int) $row['task_id'],
                'user'       => $user,
                'user_id'    => (int) $row['user_id'],
                'comment'    => wp_kses_post( $row['comment'] ),
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at']
            );
        }

        return $comments;
    }

    public static function create( $task_id, $content, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        if ( empty( trim( $content ) ) ) {
            return new WP_Error( 'missing_content', 'Comment content cannot be empty.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $insert_data = array(
            'task_id'    => (int) $task_id,
            'user_id'    => (int) $current_user->ID,
            'comment'    => wp_kses_post( $content ),
            'created_at' => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $comment_id = $wpdb->insert_id;

        if ( ! $comment_id ) {
            return new WP_Error( 'db_error', 'Failed to save comment.', array( 'status' => 500 ) );
        }

        // Get task to notify assignee, creator, and mentioned users
        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );
        if ( $task ) {
            $author_name = $current_user->display_name ?: $current_user->user_login;
            
            // 1. Detect @mentions in comment body (e.g. @Karthik, @balaji, @anirudh, @admin)
            $mentioned_users = array();
            if ( preg_match_all( '/@([a-zA-Z0-9_\.\-]+)/', $content, $matches ) ) {
                $raw_mentions = array_unique( $matches[1] );
                foreach ( $raw_mentions as $mention_str ) {
                    $u = get_user_by( 'login', $mention_str );
                    if ( ! $u ) {
                        $u = get_user_by( 'slug', $mention_str );
                    }
                    if ( ! $u ) {
                        $searched = get_users( array(
                            'search'         => '*' . esc_attr( $mention_str ) . '*',
                            'search_columns' => array( 'display_name', 'user_nicename', 'user_login' ),
                            'number'         => 1
                        ) );
                        if ( ! empty( $searched ) ) {
                            $u = $searched[0];
                        }
                    }
                    if ( $u ) {
                        $mentioned_users[] = (int) $u->ID;
                    }
                }
            }
            $mentioned_users = array_unique( $mentioned_users );

            // Dispatch high-priority mention notifications
            foreach ( $mentioned_users as $m_uid ) {
                ShootSide_PM_Notifications::create(
                    $m_uid,
                    'mention',
                    "{$author_name} mentioned you on '{$task['title']}'",
                    "{$author_name}: \"" . wp_trim_words( strip_tags( $content ), 12 ) . "\"",
                    'task',
                    $task_id
                );
            }

            // 2. Notify assignee and creator (if not already notified via mention)
            $notify_users = array();
            if ( $task['assigned_to_id'] && (int) $task['assigned_to_id'] !== (int) $current_user->ID ) {
                $notify_users[] = (int) $task['assigned_to_id'];
            }
            if ( $task['created_by_id'] && (int) $task['created_by_id'] !== (int) $current_user->ID ) {
                $notify_users[] = (int) $task['created_by_id'];
            }

            $notify_users = array_unique( $notify_users );
            $general_notify_users = array_diff( $notify_users, $mentioned_users );

            foreach ( $general_notify_users as $target_uid ) {
                ShootSide_PM_Notifications::create(
                    $target_uid,
                    'new_comment',
                    "New comment on '{$task['title']}'",
                    "{$author_name}: \"" . wp_trim_words( strip_tags( $content ), 10 ) . "\"",
                    'task',
                    $task_id
                );
            }

            // Log activity
            ShootSide_PM_Activity::log(
                $current_user->ID,
                'task',
                $task_id,
                'comment_added',
                null,
                wp_trim_words( strip_tags( $content ), 8 ),
                array( 'comment_id' => $comment_id )
            );
        }

        return array(
            'id'         => $comment_id,
            'task_id'    => (int) $task_id,
            'user'       => ShootSide_PM_Auth::format_user( $current_user ),
            'user_id'    => (int) $current_user->ID,
            'comment'    => $insert_data['comment'],
            'created_at' => $insert_data['created_at'],
            'updated_at' => $insert_data['created_at']
        );
    }

    public static function get_for_subtask( $subtask_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE subtask_id = %d AND deleted_at IS NULL ORDER BY created_at ASC", (int) $subtask_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $comments = array();
        foreach ( (array) $rows as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $comments[] = array(
                'id'         => (int) $row['id'],
                'task_id'    => (int) $row['task_id'],
                'subtask_id' => (int) $row['subtask_id'],
                'user'       => $user,
                'user_id'    => (int) $row['user_id'],
                'comment'    => wp_kses_post( $row['comment'] ),
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at']
            );
        }

        return $comments;
    }

    public static function create_for_subtask( $subtask_id, $content, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        if ( empty( trim( $content ) ) ) {
            return new WP_Error( 'missing_content', 'Comment content cannot be empty.', array( 'status' => 400 ) );
        }

        $subtask = ShootSide_PM_Subtasks::get_by_id( $subtask_id );
        if ( ! $subtask ) {
            return new WP_Error( 'not_found', 'Subtask not found.', array( 'status' => 404 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $task_id = (int) $subtask['task_id'];

        $insert_data = array(
            'task_id'    => $task_id,
            'subtask_id' => (int) $subtask_id,
            'user_id'    => (int) $current_user->ID,
            'comment'    => wp_kses_post( $content ),
            'created_at' => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $comment_id = $wpdb->insert_id;

        if ( ! $comment_id ) {
            return new WP_Error( 'db_error', 'Failed to save comment.', array( 'status' => 500 ) );
        }

        $author_name = $current_user->display_name ?: $current_user->user_login;
        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );

        // 1. Detect @mentions in subtask comment
        $mentioned_users = array();
        if ( preg_match_all( '/@([a-zA-Z0-9_\.\-]+)/', $content, $matches ) ) {
            $raw_mentions = array_unique( $matches[1] );
            foreach ( $raw_mentions as $mention_str ) {
                $u = get_user_by( 'login', $mention_str );
                if ( ! $u ) {
                    $u = get_user_by( 'slug', $mention_str );
                }
                if ( ! $u ) {
                    $searched = get_users( array(
                        'search'         => '*' . esc_attr( $mention_str ) . '*',
                        'search_columns' => array( 'display_name', 'user_nicename', 'user_login' ),
                        'number'         => 1
                    ) );
                    if ( ! empty( $searched ) ) {
                        $u = $searched[0];
                    }
                }
                if ( $u ) {
                    $mentioned_users[] = (int) $u->ID;
                }
            }
        }
        $mentioned_users = array_unique( $mentioned_users );

        // Dispatch high-priority mention notifications
        foreach ( $mentioned_users as $m_uid ) {
            ShootSide_PM_Notifications::create(
                $m_uid,
                'mention',
                "{$author_name} mentioned you on subtask '{$subtask['title']}'",
                "{$author_name}: \"" . wp_trim_words( strip_tags( $content ), 12 ) . "\"",
                'task',
                $task_id
            );
        }

        // 2. Notify subtask assignee and creator
        $notify_users = array();
        if ( ! empty( $subtask['assigned_to_id'] ) && (int) $subtask['assigned_to_id'] !== (int) $current_user->ID ) {
            $notify_users[] = (int) $subtask['assigned_to_id'];
        }
        if ( ! empty( $subtask['created_by'] ) && (int) $subtask['created_by'] !== (int) $current_user->ID ) {
            $notify_users[] = (int) $subtask['created_by'];
        }

        $notify_users = array_unique( $notify_users );
        $general_notify_users = array_diff( $notify_users, $mentioned_users );

        foreach ( $general_notify_users as $target_uid ) {
            ShootSide_PM_Notifications::create(
                $target_uid,
                'new_comment',
                "New comment on subtask '{$subtask['title']}'",
                "{$author_name}: \"" . wp_trim_words( strip_tags( $content ), 10 ) . "\"",
                'task',
                $task_id
            );
        }

        // 3. Log activity
        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $task_id,
            'subtask_comment_added',
            $subtask['title'],
            wp_trim_words( strip_tags( $content ), 8 ),
            json_encode( array( 'subtask_id' => $subtask_id, 'comment_id' => $comment_id ) )
        );

        return array(
            'id'         => $comment_id,
            'task_id'    => $task_id,
            'subtask_id' => (int) $subtask_id,
            'user'       => ShootSide_PM_Auth::format_user( $current_user ),
            'user_id'    => (int) $current_user->ID,
            'comment'    => $insert_data['comment'],
            'created_at' => $insert_data['created_at'],
            'updated_at' => $insert_data['created_at']
        );
    }

    public static function delete( $comment_id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $comment = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d AND deleted_at IS NULL", (int) $comment_id ), ARRAY_A );
        if ( ! $comment ) {
            return new WP_Error( 'not_found', 'Comment not found or already deleted.', array( 'status' => 404 ) );
        }

        $now = current_time( 'mysql' );
        $wpdb->update( $table, array( 'deleted_at' => $now ), array( 'id' => (int) $comment_id ) );

        $author = ShootSide_PM_Auth::format_user( $comment['user_id'] );
        $author_name = $author ? $author['name'] : 'User';

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            (int) $comment['task_id'],
            'comment_deleted',
            $author_name,
            wp_trim_words( strip_tags( $comment['comment'] ), 8 ),
            json_encode( array( 'comment_id' => $comment_id, 'subtask_id' => $comment['subtask_id'] ) )
        );

        return true;
    }
}
