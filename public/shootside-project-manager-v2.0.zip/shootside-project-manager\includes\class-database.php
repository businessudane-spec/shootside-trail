<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Database {

    public static function get_table_name( $table ) {
        global $wpdb;
        return $wpdb->prefix . 'pm_' . $table;
    }

    public static function migrate() {
        global $wpdb;
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

        $charset_collate = $wpdb->get_charset_collate();

        $table_projects         = self::get_table_name( 'projects' );
        $table_project_members = self::get_table_name( 'project_members' );
        $table_tasks            = self::get_table_name( 'tasks' );
        $table_comments         = self::get_table_name( 'comments' );
        $table_attachments      = self::get_table_name( 'attachments' );
        $table_activity         = self::get_table_name( 'activity' );
        $table_notifications    = self::get_table_name( 'notifications' );
        $table_vault            = self::get_table_name( 'vault' );
        $table_subtasks         = self::get_table_name( 'subtasks' );

        $sql = "
        CREATE TABLE {$table_projects} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_name varchar(255) NOT NULL,
            client_name varchar(255) NOT NULL DEFAULT '',
            description longtext NOT NULL,
            start_date date NULL,
            deadline date NULL,
            project_manager_id bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(50) NOT NULL DEFAULT 'Active',
            priority varchar(50) NOT NULL DEFAULT 'Medium',
            progress int(3) NOT NULL DEFAULT 0,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            deleted_at datetime NULL,
            PRIMARY KEY  (id),
            KEY status (status),
            KEY priority (priority),
            KEY project_manager_id (project_manager_id),
            KEY deleted_at (deleted_at)
        ) {$charset_collate};

        CREATE TABLE {$table_project_members} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY project_user (project_id, user_id),
            KEY project_id (project_id),
            KEY user_id (user_id)
        ) {$charset_collate};

        CREATE TABLE {$table_tasks} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned NOT NULL,
            title varchar(255) NOT NULL,
            description longtext NOT NULL,
            assigned_to bigint(20) unsigned NOT NULL DEFAULT 0,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(50) NOT NULL DEFAULT 'To Do',
            priority varchar(50) NOT NULL DEFAULT 'Medium',
            start_date date NULL,
            due_date date NULL,
            estimated_hours decimal(6,2) NOT NULL DEFAULT 0.00,
            actual_hours decimal(6,2) NOT NULL DEFAULT 0.00,
            progress int(3) NOT NULL DEFAULT 0,
            parent_task_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            deleted_at datetime NULL,
            PRIMARY KEY  (id),
            KEY project_id (project_id),
            KEY parent_task_id (parent_task_id),
            KEY assigned_to (assigned_to),
            KEY created_by (created_by),
            KEY status (status),
            KEY priority (priority),
            KEY due_date (due_date),
            KEY deleted_at (deleted_at)
        ) {$charset_collate};

        CREATE TABLE {$table_comments} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            task_id bigint(20) unsigned NOT NULL DEFAULT 0,
            subtask_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NOT NULL,
            comment longtext NOT NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            deleted_at datetime NULL,
            PRIMARY KEY  (id),
            KEY task_id (task_id),
            KEY subtask_id (subtask_id),
            KEY user_id (user_id),
            KEY deleted_at (deleted_at)
        ) {$charset_collate};

        CREATE TABLE {$table_attachments} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            project_id bigint(20) unsigned NOT NULL DEFAULT 0,
            task_id bigint(20) unsigned NOT NULL DEFAULT 0,
            user_id bigint(20) unsigned NOT NULL,
            file_url text NOT NULL,
            file_name varchar(255) NOT NULL,
            file_type varchar(100) NOT NULL DEFAULT '',
            file_size bigint(20) unsigned NOT NULL DEFAULT 0,
            attachment_id bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY project_id (project_id),
            KEY task_id (task_id),
            KEY user_id (user_id)
        ) {$charset_collate};

        CREATE TABLE {$table_activity} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            entity_type varchar(50) NOT NULL,
            entity_id bigint(20) unsigned NOT NULL,
            action varchar(100) NOT NULL,
            old_value longtext NULL,
            new_value longtext NULL,
            metadata longtext NULL,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY entity_lookup (entity_type, entity_id),
            KEY user_id (user_id),
            KEY action (action),
            KEY created_at (created_at)
        ) {$charset_collate};

        CREATE TABLE {$table_notifications} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            type varchar(50) NOT NULL DEFAULT 'system',
            title varchar(255) NOT NULL,
            message text NOT NULL,
            entity_type varchar(50) NOT NULL DEFAULT '',
            entity_id bigint(20) unsigned NOT NULL DEFAULT 0,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY is_read (is_read),
            KEY created_at (created_at)
        ) {$charset_collate};

        CREATE TABLE {$table_vault} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            title varchar(255) NOT NULL,
            category varchar(100) NOT NULL DEFAULT 'General',
            service_url varchar(255) NOT NULL DEFAULT '',
            username varchar(255) NOT NULL DEFAULT '',
            password text NOT NULL,
            notes text NOT NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            deleted_at datetime NULL,
            PRIMARY KEY  (id),
            KEY category (category),
            KEY created_by (created_by),
            KEY deleted_at (deleted_at)
        ) {$charset_collate};

        CREATE TABLE {$table_subtasks} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            task_id bigint(20) unsigned NOT NULL,
            title varchar(255) NOT NULL,
            assigned_to bigint(20) unsigned NOT NULL DEFAULT 0,
            status varchar(50) NOT NULL DEFAULT 'todo',
            due_date date NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            deleted_at datetime NULL,
            PRIMARY KEY  (id),
            KEY task_id (task_id),
            KEY assigned_to (assigned_to),
            KEY status (status),
            KEY deleted_at (deleted_at)
        ) {$charset_collate};
        ";

        dbDelta( $sql );

        // Ensure subtask_id column exists on existing comments table
        $col_check = $wpdb->get_results( "SHOW COLUMNS FROM {$table_comments} LIKE 'subtask_id'" );
        if ( empty( $col_check ) ) {
            $wpdb->query( "ALTER TABLE {$table_comments} ADD COLUMN subtask_id bigint(20) unsigned NOT NULL DEFAULT 0 AFTER task_id" );
            $wpdb->query( "ALTER TABLE {$table_comments} ADD INDEX subtask_id (subtask_id)" );
        }

        // Ensure parent_task_id column exists on existing tasks table
        $parent_task_col_check = $wpdb->get_results( "SHOW COLUMNS FROM {$table_tasks} LIKE 'parent_task_id'" );
        if ( empty( $parent_task_col_check ) ) {
            $wpdb->query( "ALTER TABLE {$table_tasks} ADD COLUMN parent_task_id bigint(20) unsigned NOT NULL DEFAULT 0 AFTER progress" );
            $wpdb->query( "ALTER TABLE {$table_tasks} ADD INDEX parent_task_id (parent_task_id)" );
        }

        update_option( 'shootside_pm_db_version', SHOOTSIDE_PM_VERSION );
    }
}
