<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Attachments {

    public static function get_for_task( $task_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'attachments' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE task_id = %d ORDER BY created_at DESC", (int) $task_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $attachments = array();
        foreach ( (array) $rows as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $stream_url = rest_url( 'shootside-pm/v1/attachments/' . $row['id'] . '/file' );
            $attachments[] = array(
                'id'            => (int) $row['id'],
                'project_id'    => (int) $row['project_id'],
                'task_id'       => (int) $row['task_id'],
                'user'          => $user,
                'user_id'       => (int) $row['user_id'],
                'file_url'      => $stream_url,
                'direct_url'    => $row['file_url'],
                'stream_url'    => $stream_url,
                'file_name'     => $row['file_name'],
                'file_type'     => $row['file_type'],
                'file_size'     => (int) $row['file_size'],
                'attachment_id' => (int) $row['attachment_id'],
                'created_at'    => $row['created_at']
            );
        }

        return $attachments;
    }

    public static function stream_file( $attachment_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'attachments' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $attachment_id ), ARRAY_A );
        if ( ! $row ) {
            return new WP_Error( 'not_found', 'Attachment not found.', array( 'status' => 404 ) );
        }

        $upload_dir = wp_upload_dir();
        $file_url = $row['file_url'];
        $file_path = '';
        
        // Match relative path after /wp-content/uploads/
        if ( preg_match( '#/wp-content/uploads/(.+)$#', $file_url, $matches ) ) {
            $file_path = $upload_dir['basedir'] . '/' . $matches[1];
        }

        if ( empty( $file_path ) || ! file_exists( $file_path ) ) {
            $file_path = $upload_dir['path'] . '/' . $row['file_name'];
        }

        if ( ! file_exists( $file_path ) ) {
            $file_path = $upload_dir['basedir'] . '/' . $row['file_name'];
        }

        if ( ! file_exists( $file_path ) ) {
            // Check direct URL if path
            $clean_rel = str_replace( $upload_dir['baseurl'], '', $file_url );
            $file_path = $upload_dir['basedir'] . $clean_rel;
        }

        if ( ! file_exists( $file_path ) ) {
            return new WP_Error( 'file_missing', 'Attachment file not found on server.', array( 'status' => 404 ) );
        }

        $mime_type = ! empty( $row['file_type'] ) ? $row['file_type'] : 'application/octet-stream';

        if ( ob_get_level() ) {
            ob_end_clean();
        }

        header( 'Content-Type: ' . $mime_type );
        header( 'Content-Length: ' . filesize( $file_path ) );
        header( 'Access-Control-Allow-Origin: *' );
        header( 'Access-Control-Allow-Methods: GET, OPTIONS' );
        header( 'Cache-Control: public, max-age=86400' );
        header( 'Content-Disposition: inline; filename="' . basename( $row['file_name'] ) . '"' );

        readfile( $file_path );
        exit;
    }

    public static function upload_for_task( $task_id, $files, $current_user, $params = array() ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );
        if ( ! $task ) {
            return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) );
        }

        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        $file_name = '';
        $file_type = '';
        $file_url  = '';
        $file_size = 0;

        // Mode 1: Base64 upload (most reliable on mobile & web proxies)
        if ( ! empty( $params['file_base64'] ) ) {
            $base64_data = $params['file_base64'];
            $file_name   = sanitize_file_name( ! empty( $params['file_name'] ) ? $params['file_name'] : 'attachment-' . time() . '.png' );
            $file_type   = sanitize_text_field( ! empty( $params['file_type'] ) ? $params['file_type'] : 'image/png' );

            if ( preg_match( '/^data:([^;]+);base64,(.*)$/', $base64_data, $matches ) ) {
                $file_type = $matches[1];
                $binary_data = base64_decode( $matches[2] );
            } else {
                $binary_data = base64_decode( $base64_data );
            }

            if ( false === $binary_data ) {
                return new WP_Error( 'invalid_data', 'Invalid Base64 encoded file data.', array( 'status' => 400 ) );
            }

            $upload_dir = wp_upload_dir();
            $unique_name = time() . '-' . wp_unique_filename( $upload_dir['path'], $file_name );
            $upload = wp_upload_bits( $unique_name, null, $binary_data );

            if ( ! empty( $upload['error'] ) ) {
                return new WP_Error( 'upload_failed', $upload['error'], array( 'status' => 400 ) );
            }

            $file_url  = $upload['url'];
            $file_size = strlen( $binary_data );
        }
        // Mode 2: Standard Multipart $_FILES upload
        elseif ( ! empty( $files['file'] ) ) {
            $uploaded_file = $files['file'];
            $upload_overrides = array( 'test_form' => false );
            $movefile = wp_handle_upload( $uploaded_file, $upload_overrides );

            if ( ! $movefile || isset( $movefile['error'] ) ) {
                return new WP_Error( 'upload_failed', isset( $movefile['error'] ) ? $movefile['error'] : 'File upload failed.', array( 'status' => 400 ) );
            }

            $file_name = sanitize_file_name( basename( $movefile['file'] ) );
            $file_type = $movefile['type'];
            $file_url  = $movefile['url'];
            $file_size = (int) @filesize( $movefile['file'] );
        } else {
            return new WP_Error( 'missing_file', 'No file data or attachment provided.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'attachments' );

        $insert_data = array(
            'project_id'    => (int) $task['project_id'],
            'task_id'       => (int) $task_id,
            'user_id'       => (int) $current_user->ID,
            'file_url'      => esc_url_raw( $file_url ),
            'file_name'     => $file_name,
            'file_type'     => sanitize_text_field( $file_type ),
            'file_size'     => (int) $file_size,
            'attachment_id' => 0,
            'created_at'    => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $att_id = $wpdb->insert_id;

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $task_id,
            'attachment_added',
            null,
            $file_name
        );

        $stream_url = rest_url( 'shootside-pm/v1/attachments/' . $att_id . '/file' );

        return array(
            'id'         => $att_id,
            'task_id'    => (int) $task_id,
            'project_id' => (int) $task['project_id'],
            'user'       => ShootSide_PM_Auth::format_user( $current_user ),
            'file_url'   => $stream_url,
            'direct_url' => $file_url,
            'stream_url' => $stream_url,
            'file_name'  => $file_name,
            'file_type'  => $file_type,
            'file_size'  => $file_size,
            'created_at' => $insert_data['created_at']
        );
    }

    public static function delete( $attachment_id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'attachments' );

        $attachment = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $attachment_id ), ARRAY_A );
        if ( ! $attachment ) {
            return new WP_Error( 'not_found', 'Attachment not found.', array( 'status' => 404 ) );
        }

        $is_admin = ShootSide_PM_Permissions::is_admin( $current_user );
        if ( ! $is_admin && (int) $attachment['user_id'] !== (int) $current_user->ID ) {
            return new WP_Error( 'forbidden', 'You can only delete your own attachments.', array( 'status' => 403 ) );
        }

        $wpdb->delete( $table, array( 'id' => (int) $attachment_id ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            (int) $attachment['task_id'],
            'attachment_deleted',
            $attachment['file_name'],
            'deleted'
        );

        return true;
    }
}
