<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_API {

    private $namespace = SHOOTSIDE_PM_API_NAMESPACE;

    public function register_routes() {

        // ================= AUTH ROUTES =================
        register_rest_route( $this->namespace, '/auth/login', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'auth_login' ),
            'permission_callback' => '__return_true'
        ) );

        register_rest_route( $this->namespace, '/auth/me', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'auth_me' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/auth/logout', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'auth_logout' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/auth/profile', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'auth_update_profile' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        // ================= USER ROUTES =================
        register_rest_route( $this->namespace, '/users', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_users' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/users/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_user' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        // ================= PROJECT ROUTES =================
        register_rest_route( $this->namespace, '/projects', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_projects' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_project' ),
                'permission_callback' => array( $this, 'check_admin_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/projects/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_project' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => array( $this, 'update_project' ),
                'permission_callback' => array( $this, 'check_admin_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array( $this, 'delete_project' ),
                'permission_callback' => array( $this, 'check_admin_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/projects/(?P<id>\d+)/tasks', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_project_tasks' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/projects/(?P<id>\d+)/activity', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_project_activity' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        // ================= TASK ROUTES =================
        register_rest_route( $this->namespace, '/tasks', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_tasks' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_task' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_task' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => array( $this, 'update_task' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array( $this, 'delete_task' ),
                'permission_callback' => array( $this, 'check_admin_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/merge', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'merge_task' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/unmerge', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'unmerge_task' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/tasks/merge', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'merge_tasks_bulk' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/comments', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_task_comments' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_task_comment' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/comments/(?P<comment_id>\d+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'delete_task_comment' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/comments/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'delete_comment' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/attachments', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_task_attachments' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'upload_task_attachment' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/attachments/(?P<attachment_id>\d+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'delete_task_attachment' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/attachments/(?P<id>\d+)/file', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'stream_attachment_file' ),
            'permission_callback' => '__return_true'
        ) );

        // ================= SUBTASKS ROUTES =================
        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/subtasks', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_task_subtasks' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_task_subtask' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/subtasks/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_subtask' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => array( $this, 'update_subtask' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array( $this, 'delete_subtask' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/subtasks/(?P<id>\d+)/comments', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_subtask_comments' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_subtask_comment' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/tasks/(?P<id>\d+)/activity', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_task_activity' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        // ================= NOTIFICATIONS ROUTES =================
        register_rest_route( $this->namespace, '/notifications', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_notifications' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/notifications/(?P<id>\d+)/read', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'mark_notification_read' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        register_rest_route( $this->namespace, '/notifications/read-all', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'mark_all_notifications_read' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );

        // ================= VAULT / COMPANY STORE ROUTES =================
        register_rest_route( $this->namespace, '/vault', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_vault_items' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_vault_item' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        register_rest_route( $this->namespace, '/vault/(?P<id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_vault_item' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::EDITABLE,
                'callback'            => array( $this, 'update_vault_item' ),
                'permission_callback' => array( $this, 'check_auth' )
            ),
            array(
                'methods'             => WP_REST_Server::DELETABLE,
                'callback'            => array( $this, 'delete_vault_item' ),
                'permission_callback' => array( $this, 'check_auth' )
            )
        ) );

        // ================= ADMIN & AUDIT ROUTES =================
        register_rest_route( $this->namespace, '/admin/activity', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_admin_activity' ),
            'permission_callback' => array( $this, 'check_admin_auth' )
        ) );

        register_rest_route( $this->namespace, '/admin/deleted-items', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_deleted_items' ),
            'permission_callback' => array( $this, 'check_admin_auth' )
        ) );

        register_rest_route( $this->namespace, '/admin/deleted-items/(?P<type>[a-zA-Z]+)/(?P<id>\d+)/restore', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'restore_deleted_item' ),
            'permission_callback' => array( $this, 'check_admin_auth' )
        ) );

        register_rest_route( $this->namespace, '/admin/statistics', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_statistics' ),
            'permission_callback' => array( $this, 'check_auth' )
        ) );
    }

    // ================= PERMISSION CALLBACKS =================
    public function check_auth( $request ) {
        $user = ShootSide_PM_Auth::get_current_user_from_request( $request );
        return ShootSide_PM_Permissions::is_authenticated( $user );
    }

    public function check_admin_auth( $request ) {
        $user = ShootSide_PM_Auth::get_current_user_from_request( $request );
        return ShootSide_PM_Permissions::is_admin( $user );
    }

    private function get_request_user( $request ) {
        return ShootSide_PM_Auth::get_current_user_from_request( $request );
    }

    private function json_response( $success, $data = null, $message = '', $status_code = 200 ) {
        return new WP_REST_Response( array(
            'success' => (bool) $success,
            'data'    => $data,
            'message' => $message
        ), $status_code );
    }

    // ================= ROUTE HANDLERS =================
    public function auth_login( $request ) {
        $params   = $request->get_json_params();
        $username = isset( $params['username'] ) ? sanitize_user( $params['username'] ) : '';
        $password = isset( $params['password'] ) ? $params['password'] : '';

        if ( empty( $username ) || empty( $password ) ) {
            return $this->json_response( false, null, 'Username and password are required.', 400 );
        }

        $user = wp_authenticate( $username, $password );

        if ( is_wp_error( $user ) ) {
            return $this->json_response( false, null, 'Invalid credentials. Please try again.', 401 );
        }

        $token = ShootSide_PM_Auth::generate_token( $user->ID );
        $user_data = ShootSide_PM_Auth::format_user( $user );

        ShootSide_PM_Activity::log(
            $user->ID,
            'auth',
            $user->ID,
            'logged_in',
            null,
            $user->user_login
        );

        return $this->json_response( true, array(
            'token' => $token,
            'user'  => $user_data
        ), 'Login successful.' );
    }

    public function auth_me( $request ) {
        $user = $this->get_request_user( $request );
        return $this->json_response( true, ShootSide_PM_Auth::format_user( $user ) );
    }

    public function auth_logout( $request ) {
        $user = $this->get_request_user( $request );
        if ( $user ) {
            ShootSide_PM_Activity::log( $user->ID, 'auth', $user->ID, 'logged_out' );
        }
        return $this->json_response( true, null, 'Logged out successfully.' );
    }

    public function auth_update_profile( $request ) {
        $user = $this->get_request_user( $request );
        if ( ! $user ) {
            return $this->json_response( false, null, 'Unauthorized.', 401 );
        }

        $params   = $request->get_json_params();
        $name     = isset( $params['name'] ) ? sanitize_text_field( $params['name'] ) : '';
        $email    = isset( $params['email'] ) ? sanitize_email( $params['email'] ) : '';
        $password = isset( $params['password'] ) ? $params['password'] : '';

        $update_data = array(
            'ID' => $user->ID,
        );

        if ( ! empty( $name ) ) {
            $update_data['display_name'] = $name;
            $update_data['first_name']   = $name;
        }

        if ( ! empty( $email ) ) {
            if ( ! is_email( $email ) ) {
                return $this->json_response( false, null, 'Invalid email address format.', 400 );
            }
            $existing_user = get_user_by( 'email', $email );
            if ( $existing_user && (int) $existing_user->ID !== (int) $user->ID ) {
                return $this->json_response( false, null, 'Email is already in use by another account.', 400 );
            }
            $update_data['user_email'] = $email;
        }

        if ( ! empty( $password ) ) {
            if ( strlen( $password ) < 6 ) {
                return $this->json_response( false, null, 'Password must be at least 6 characters long.', 400 );
            }
            $update_data['user_pass'] = $password;
        }

        $avatar = $request->get_param( 'avatar' );
        if ( $avatar !== null ) {
            update_user_meta( $user->ID, 'shootside_pm_avatar', $avatar );
        }

        $result = wp_update_user( $update_data );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), 400 );
        }

        $updated_user = ShootSide_PM_Auth::format_user( $user->ID );
        ShootSide_PM_Activity::log( $user->ID, 'user', $user->ID, 'updated_profile' );

        return $this->json_response( true, $updated_user, 'Profile details updated successfully.' );
    }

    public function get_users( $request ) {
        return $this->json_response( true, ShootSide_PM_Auth::get_all_users() );
    }

    public function get_user( $request ) {
        $user = ShootSide_PM_Auth::format_user( (int) $request['id'] );
        if ( ! $user ) {
            return $this->json_response( false, null, 'User not found.', 404 );
        }
        return $this->json_response( true, $user );
    }

    public function get_projects( $request ) {
        $user = $this->get_request_user( $request );
        $args = array(
            'status'   => $request->get_param( 'status' ),
            'priority' => $request->get_param( 'priority' ),
            'search'   => $request->get_param( 'search' )
        );
        $projects = ShootSide_PM_Projects::get_all( $args, $user );
        return $this->json_response( true, $projects );
    }

    public function get_project( $request ) {
        $user = $this->get_request_user( $request );
        $project = ShootSide_PM_Projects::get_by_id( (int) $request['id'], $user );
        if ( ! $project ) {
            return $this->json_response( false, null, 'Project not found.', 404 );
        }
        return $this->json_response( true, $project );
    }

    public function create_project( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        if ( empty( $params['project_name'] ) ) {
            return $this->json_response( false, null, 'Project name is required.', 400 );
        }

        $result = ShootSide_PM_Projects::create( $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Project created successfully.', 201 );
    }

    public function update_project( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $result = ShootSide_PM_Projects::update( (int) $request['id'], $params, $user );

        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Project updated successfully.' );
    }

    public function delete_project( $request ) {
        $user = $this->get_request_user( $request );
        $result = ShootSide_PM_Projects::soft_delete( (int) $request['id'], $user );

        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Project moved to trash.' );
    }

    public function get_project_tasks( $request ) {
        $user = $this->get_request_user( $request );
        $tasks = ShootSide_PM_Tasks::get_all( array( 'project_id' => (int) $request['id'] ), $user );
        return $this->json_response( true, $tasks );
    }

    public function get_project_activity( $request ) {
        $activities = ShootSide_PM_Activity::get_activities( array(
            'entity_type' => 'project',
            'entity_id'   => (int) $request['id']
        ) );
        return $this->json_response( true, $activities );
    }

    public function get_tasks( $request ) {
        $user = $this->get_request_user( $request );
        $args = array(
            'project_id'  => $request->get_param( 'project_id' ),
            'assigned_to' => $request->get_param( 'assigned_to' ),
            'status'      => $request->get_param( 'status' ),
            'priority'    => $request->get_param( 'priority' ),
            'search'      => $request->get_param( 'search' )
        );
        $tasks = ShootSide_PM_Tasks::get_all( $args, $user );
        return $this->json_response( true, $tasks );
    }

    public function get_task( $request ) {
        $user = $this->get_request_user( $request );
        $task = ShootSide_PM_Tasks::get_by_id( (int) $request['id'], $user );
        if ( ! $task ) {
            return $this->json_response( false, null, 'Task not found.', 404 );
        }
        return $this->json_response( true, $task );
    }

    public function create_task( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        if ( empty( $params['title'] ) || empty( $params['project_id'] ) ) {
            return $this->json_response( false, null, 'Task title and project are required.', 400 );
        }

        $result = ShootSide_PM_Tasks::create( $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Task created successfully.', 201 );
    }

    public function update_task( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $result = ShootSide_PM_Tasks::update( (int) $request['id'], $params, $user );

        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Task updated successfully.' );
    }

    public function delete_task( $request ) {
        $user = $this->get_request_user( $request );
        $result = ShootSide_PM_Tasks::soft_delete( (int) $request['id'], $user );

        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Task moved to trash.' );
    }

    public function merge_task( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $primary_task_id = (int) $request['id'];

        $child_task_ids = array();
        if ( isset( $params['child_task_ids'] ) && is_array( $params['child_task_ids'] ) ) {
            $child_task_ids = $params['child_task_ids'];
        } elseif ( isset( $params['child_task_id'] ) ) {
            $child_task_ids = array( (int) $params['child_task_id'] );
        }

        $options = array(
            'close_child_tasks' => ! empty( $params['close_child_tasks'] )
        );

        $result = ShootSide_PM_Tasks::merge_tasks( $primary_task_id, $child_task_ids, $options, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Task(s) merged successfully.' );
    }

    public function unmerge_task( $request ) {
        $user = $this->get_request_user( $request );
        $task_id = (int) $request['id'];

        $result = ShootSide_PM_Tasks::unmerge_task( $task_id, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Task unmerged successfully.' );
    }

    public function merge_tasks_bulk( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $primary_task_id = ! empty( $params['primary_task_id'] ) ? (int) $params['primary_task_id'] : 0;
        $child_task_ids = ! empty( $params['child_task_ids'] ) && is_array( $params['child_task_ids'] ) ? $params['child_task_ids'] : array();

        if ( ! $primary_task_id || empty( $child_task_ids ) ) {
            return $this->json_response( false, null, 'Primary task ID and child task IDs are required.', 400 );
        }

        $options = array(
            'close_child_tasks' => ! empty( $params['close_child_tasks'] )
        );

        $result = ShootSide_PM_Tasks::merge_tasks( $primary_task_id, $child_task_ids, $options, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Task(s) merged successfully.' );
    }

    public function get_task_comments( $request ) {
        $comments = ShootSide_PM_Comments::get_for_task( (int) $request['id'] );
        return $this->json_response( true, $comments );
    }

    public function create_task_comment( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $content = isset( $params['comment'] ) ? $params['comment'] : '';

        $result = ShootSide_PM_Comments::create( (int) $request['id'], $content, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Comment added successfully.', 201 );
    }

    public function delete_task_comment( $request ) {
        $user = $this->get_request_user( $request );
        $comment_id = ! empty( $request['comment_id'] ) ? (int) $request['comment_id'] : (int) $request['id'];
        $result = ShootSide_PM_Comments::delete( $comment_id, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Comment deleted successfully.' );
    }

    public function delete_comment( $request ) {
        $user = $this->get_request_user( $request );
        $comment_id = (int) $request['id'];
        $result = ShootSide_PM_Comments::delete( $comment_id, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Comment deleted successfully.' );
    }

    public function get_task_attachments( $request ) {
        $attachments = ShootSide_PM_Attachments::get_for_task( (int) $request['id'] );
        return $this->json_response( true, $attachments );
    }

    public function upload_task_attachment( $request ) {
        $user = $this->get_request_user( $request );
        $files = $request->get_file_params();
        $params = $request->get_json_params();

        $result = ShootSide_PM_Attachments::upload_for_task( (int) $request['id'], $files, $user, $params );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'File uploaded successfully.', 201 );
    }

    public function delete_task_attachment( $request ) {
        $user = $this->get_request_user( $request );
        $result = ShootSide_PM_Attachments::delete( (int) $request['attachment_id'], $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Attachment removed successfully.' );
    }

    public function stream_attachment_file( $request ) {
        $id = (int) $request['id'];
        $result = ShootSide_PM_Attachments::stream_file( $id );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), 404 );
        }
        return $result;
    }

    public function get_task_activity( $request ) {
        $activities = ShootSide_PM_Activity::get_activities( array(
            'entity_type' => 'task',
            'entity_id'   => (int) $request['id']
        ) );
        return $this->json_response( true, $activities );
    }

    public function get_notifications( $request ) {
        $user = $this->get_request_user( $request );
        $notifications = ShootSide_PM_Notifications::get_for_user( $user->ID );
        $unread_count = ShootSide_PM_Notifications::get_unread_count( $user->ID );

        return $this->json_response( true, array(
            'items'        => $notifications,
            'unread_count' => $unread_count
        ) );
    }

    public function mark_notification_read( $request ) {
        $user = $this->get_request_user( $request );
        ShootSide_PM_Notifications::mark_as_read( (int) $request['id'], $user->ID );
        return $this->json_response( true, null, 'Notification marked as read.' );
    }

    public function mark_all_notifications_read( $request ) {
        $user = $this->get_request_user( $request );
        ShootSide_PM_Notifications::mark_all_as_read( $user->ID );
        return $this->json_response( true, null, 'All notifications marked as read.' );
    }

    public function get_admin_activity( $request ) {
        $args = array(
            'entity_type' => $request->get_param( 'entity_type' ),
            'user_id'     => $request->get_param( 'user_id' ),
            'action'      => $request->get_param( 'action' ),
            'date_from'   => $request->get_param( 'date_from' ),
            'date_to'     => $request->get_param( 'date_to' ),
            'limit'       => $request->get_param( 'limit' ) ? (int) $request->get_param( 'limit' ) : 100
        );
        $activities = ShootSide_PM_Activity::get_activities( $args );
        return $this->json_response( true, $activities );
    }

    public function get_deleted_items( $request ) {
        $user = $this->get_request_user( $request );
        $deleted_projects = ShootSide_PM_Projects::get_all( array( 'deleted' => 1 ), $user );
        $deleted_tasks    = ShootSide_PM_Tasks::get_all( array( 'deleted' => 1 ), $user );

        return $this->json_response( true, array(
            'projects' => $deleted_projects,
            'tasks'    => $deleted_tasks
        ) );
    }

    public function restore_deleted_item( $request ) {
        $user = $this->get_request_user( $request );
        $type = sanitize_key( $request['type'] );
        $id   = (int) $request['id'];

        if ( $type === 'project' || $type === 'projects' ) {
            $result = ShootSide_PM_Projects::restore( $id, $user );
        } elseif ( $type === 'task' || $type === 'tasks' ) {
            $result = ShootSide_PM_Tasks::restore( $id, $user );
        } else {
            return $this->json_response( false, null, 'Invalid item type.', 400 );
        }

        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Item restored successfully.' );
    }

    public function get_statistics( $request ) {
        global $wpdb;
        $user = $this->get_request_user( $request );

        $tbl_p = ShootSide_PM_Database::get_table_name( 'projects' );
        $tbl_t = ShootSide_PM_Database::get_table_name( 'tasks' );

        $total_projects = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_p} WHERE deleted_at IS NULL" );
        $active_projects = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_p} WHERE status = 'Active' AND deleted_at IS NULL" );
        $completed_projects = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_p} WHERE status = 'Completed' AND deleted_at IS NULL" );

        $total_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_t} WHERE deleted_at IS NULL" );
        $todo_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_t} WHERE status = 'To Do' AND deleted_at IS NULL" );
        $in_progress_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_t} WHERE status = 'In Progress' AND deleted_at IS NULL" );
        $review_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_t} WHERE status = 'Review' AND deleted_at IS NULL" );
        $completed_tasks = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$tbl_t} WHERE status = 'Completed' AND deleted_at IS NULL" );

        $today = current_time( 'Y-m-d' );
        $end_of_week = date( 'Y-m-d', strtotime( '+7 days', strtotime( $today ) ) );

        $overdue_tasks = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl_t} WHERE due_date < %s AND status != 'Completed' AND deleted_at IS NULL", $today ) );
        $due_today_tasks = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl_t} WHERE due_date = %s AND status != 'Completed' AND deleted_at IS NULL", $today ) );
        $due_week_tasks = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl_t} WHERE due_date >= %s AND due_date <= %s AND status != 'Completed' AND deleted_at IS NULL", $today, $end_of_week ) );

        // Member specific stats
        $my_tasks_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl_t} WHERE assigned_to = %d AND status != 'Completed' AND deleted_at IS NULL", $user->ID ) );

        return $this->json_response( true, array(
            'projects' => array(
                'total'     => $total_projects,
                'active'    => $active_projects,
                'completed' => $completed_projects
            ),
            'tasks' => array(
                'total'       => $total_tasks,
                'todo'        => $todo_tasks,
                'in_progress' => $in_progress_tasks,
                'review'      => $review_tasks,
                'completed'   => $completed_tasks,
                'overdue'     => $overdue_tasks,
                'due_today'   => $due_today_tasks,
                'due_week'    => $due_week_tasks,
                'my_tasks'    => $my_tasks_count
            )
        ) );
    }

    public function get_vault_items( $request ) {
        $user = $this->get_request_user( $request );
        $args = array(
            'category' => $request->get_param( 'category' ),
            'search'   => $request->get_param( 'search' )
        );
        $items = ShootSide_PM_Vault::get_all( $args, $user );
        return $this->json_response( true, $items );
    }

    public function get_vault_item( $request ) {
        $user = $this->get_request_user( $request );
        $item = ShootSide_PM_Vault::get_by_id( (int) $request['id'], $user );
        if ( ! $item ) {
            return $this->json_response( false, null, 'Credential not found.', 404 );
        }
        return $this->json_response( true, $item );
    }

    public function create_vault_item( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        $result = ShootSide_PM_Vault::create( $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Credential added to Company Vault.', 201 );
    }

    public function update_vault_item( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        $result = ShootSide_PM_Vault::update( (int) $request['id'], $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Credential updated successfully.' );
    }

    public function delete_vault_item( $request ) {
        $user = $this->get_request_user( $request );
        $result = ShootSide_PM_Vault::delete( (int) $request['id'], $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Credential removed from Company Vault.' );
    }

    public function get_task_subtasks( $request ) {
        $subtasks = ShootSide_PM_Subtasks::get_for_task( (int) $request['id'] );
        return $this->json_response( true, $subtasks );
    }

    public function create_task_subtask( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        $result = ShootSide_PM_Subtasks::create( (int) $request['id'], $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Subtask created successfully.', 201 );
    }

    public function get_subtask( $request ) {
        $subtask = ShootSide_PM_Subtasks::get_by_id( (int) $request['id'] );
        if ( ! $subtask ) {
            return $this->json_response( false, null, 'Subtask not found.', 404 );
        }
        return $this->json_response( true, $subtask );
    }

    public function update_subtask( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();

        $result = ShootSide_PM_Subtasks::update( (int) $request['id'], $params, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Subtask updated successfully.' );
    }

    public function delete_subtask( $request ) {
        $user = $this->get_request_user( $request );
        $result = ShootSide_PM_Subtasks::delete( (int) $request['id'], $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, null, 'Subtask deleted successfully.' );
    }

    public function get_subtask_comments( $request ) {
        $comments = ShootSide_PM_Comments::get_for_subtask( (int) $request['id'] );
        return $this->json_response( true, $comments );
    }

    public function create_subtask_comment( $request ) {
        $user = $this->get_request_user( $request );
        $params = $request->get_json_params();
        $content = isset( $params['comment'] ) ? $params['comment'] : '';

        $result = ShootSide_PM_Comments::create_for_subtask( (int) $request['id'], $content, $user );
        if ( is_wp_error( $result ) ) {
            return $this->json_response( false, null, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
        }

        return $this->json_response( true, $result, 'Comment added to subtask successfully.', 201 );
    }
}
