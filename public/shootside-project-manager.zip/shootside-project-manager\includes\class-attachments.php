<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Attachments {

    public static function get_for_task( $task_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'attachments' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE task_id = %d ORDER BY created_at DESC", (int) $task_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $attachments = array();
        foreach ( (array) $rows as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $attachments[] = array(
                'id'            => (int) $row['id'],
                'project_id'    => (int) $row['project_id'],
                'task_id'       => (int) $row['task_id'],
                'user'          => $user,
                'user_id'       => (int) $row['user_id'],
                'file_url'      => $row['file_url'],
                'file_name'     => $row['file_name'],
                'file_type'     => $row['file_type'],
                'file_size'     => (int) $row['file_size'],
                'attachment_id' => (int) $row['attachment_id'],
                'created_at'    => $row['created_at']
            );
        }

        return $attachments;
    }

    public static function upload_for_task( $task_id, $files, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        require_once( ABSPATH . 'wp-admin/includes/file.php' );
        require_once( ABSPATH . 'wp-admin/includes/image.php' );
        require_once( ABSPATH . 'wp-admin/includes/media.php' );

        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );
        if ( ! $task ) {
            return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) );
        }

        if ( empty( $files['file'] ) ) {
            return new WP_Error( 'missing_file', 'No file provided.', array( 'status' => 400 ) );
        }

        $uploaded_file = $files['file'];
        $upload_overrides = array( 'test_form' => false );
        $movefile = wp_handle_upload( $uploaded_file, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) {
            global $wpdb;
            $table = ShootSide_PM_Database::get_table_name( 'attachments' );

            $file_name = sanitize_file_name( basename( $movefile['file'] ) );
            $file_type = $movefile['type'];
            $file_url  = $movefile['url'];
            $file_size = @filesize( $movefile['file'] );

            $insert_data = array(
                'project_id'    => (int) $task['project_id'],
                'task_id'       => (int) $task_id,
                'user_id'       => (int) $current_user->ID,
                'file_url'      => esc_url_raw( $file_url ),
                'file_name'     => $file_name,
                'file_type'     => sanitize_text_field( $file_type ),
                'file_size'     => (int) $file_size,
                'attachment_id' => 0,
                'created_at'    => current_time( 'mysql' )
            );

            $wpdb->insert( $table, $insert_data );
            $att_id = $wpdb->insert_id;

            ShootSide_PM_Activity::log(
                $current_user->ID,
                'task',
                $task_id,
                'attachment_added',
                null,
                $file_name
            );

            return array(
                'id'         => $att_id,
                'task_id'    => (int) $task_id,
                'project_id' => (int) $task['project_id'],
                'user'       => ShootSide_PM_Auth::format_user( $current_user ),
                'file_url'   => $file_url,
                'file_name'  => $file_name,
                'file_type'  => $file_type,
                'file_size'  => $file_size,
                'created_at' => $insert_data['created_at']
            );
        } else {
            return new WP_Error( 'upload_failed', isset( $movefile['error'] ) ? $movefile['error'] : 'File upload failed.', array( 'status' => 400 ) );
        }
    }
}
