<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Comments {

    public static function get_for_task( $task_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE task_id = %d AND deleted_at IS NULL ORDER BY created_at ASC", (int) $task_id );
        $rows = $wpdb->get_results( $sql, ARRAY_A );

        $comments = array();
        foreach ( (array) $rows as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $comments[] = array(
                'id'         => (int) $row['id'],
                'task_id'    => (int) $row['task_id'],
                'user'       => $user,
                'user_id'    => (int) $row['user_id'],
                'comment'    => wp_kses_post( $row['comment'] ),
                'created_at' => $row['created_at'],
                'updated_at' => $row['updated_at']
            );
        }

        return $comments;
    }

    public static function create( $task_id, $content, $current_user ) {
        if ( ! ShootSide_PM_Permissions::is_authenticated( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        if ( empty( trim( $content ) ) ) {
            return new WP_Error( 'missing_content', 'Comment content cannot be empty.', array( 'status' => 400 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'comments' );

        $insert_data = array(
            'task_id'    => (int) $task_id,
            'user_id'    => (int) $current_user->ID,
            'comment'    => wp_kses_post( $content ),
            'created_at' => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $comment_id = $wpdb->insert_id;

        if ( ! $comment_id ) {
            return new WP_Error( 'db_error', 'Failed to save comment.', array( 'status' => 500 ) );
        }

        // Get task to notify assignee and creator
        $task = ShootSide_PM_Tasks::get_by_id( $task_id, $current_user );
        if ( $task ) {
            $author_name = $current_user->display_name ?: $current_user->user_login;
            $notify_users = array();

            if ( $task['assigned_to_id'] && (int) $task['assigned_to_id'] !== (int) $current_user->ID ) {
                $notify_users[] = $task['assigned_to_id'];
            }
            if ( $task['created_by_id'] && (int) $task['created_by_id'] !== (int) $current_user->ID ) {
                $notify_users[] = $task['created_by_id'];
            }

            $notify_users = array_unique( $notify_users );
            foreach ( $notify_users as $target_uid ) {
                ShootSide_PM_Notifications::create(
                    $target_uid,
                    'new_comment',
                    "New comment on '{$task['title']}'",
                    "{$author_name}: \"" . wp_trim_words( strip_tags( $content ), 10 ) . "\"",
                    'task',
                    $task_id
                );
            }

            // Log activity
            ShootSide_PM_Activity::log(
                $current_user->ID,
                'task',
                $task_id,
                'comment_added',
                null,
                wp_trim_words( strip_tags( $content ), 8 ),
                array( 'comment_id' => $comment_id )
            );
        }

        return array(
            'id'         => $comment_id,
            'task_id'    => (int) $task_id,
            'user'       => ShootSide_PM_Auth::format_user( $current_user ),
            'user_id'    => (int) $current_user->ID,
            'comment'    => $insert_data['comment'],
            'created_at' => $insert_data['created_at'],
            'updated_at' => $insert_data['created_at']
        );
    }
}
