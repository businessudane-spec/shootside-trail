<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Permissions {

    /**
     * Check if user is an Admin
     */
    public static function is_admin( $user ) {
        if ( ! $user || ! ( $user instanceof WP_User ) ) {
            return false;
        }
        return in_array( 'administrator', (array) $user->roles, true );
    }

    /**
     * Check if user is authenticated (either Admin or Member)
     */
    public static function is_authenticated( $user ) {
        return ( $user && ( $user instanceof WP_User ) && $user->exists() );
    }

    /**
     * Check if user can create projects (Admin only)
     */
    public static function can_create_project( $user ) {
        return self::is_admin( $user );
    }

    /**
     * Check if user can edit/delete projects (Admin only)
     */
    public static function can_manage_project( $user, $project_id ) {
        return self::is_admin( $user );
    }

    /**
     * Check if user can create tasks (Any authenticated user)
     */
    public static function can_create_task( $user ) {
        return self::is_authenticated( $user );
    }

    /**
     * Check if user can edit a task
     * Any authenticated member can edit tasks
     */
    public static function can_edit_task( $user, $task_id ) {
        return self::is_authenticated( $user );
    }

    /**
     * Strict Rule: Can user reassign an EXISTING task?
     * Only Admin can reassign an already created task.
     * Members can only assign on creation.
     */
    public static function can_reassign_task( $user, $existing_task, $new_assigned_to ) {
        if ( ! self::is_authenticated( $user ) ) {
            return false;
        }

        // If the assignment is not changing, allow update
        if ( (int) $existing_task['assigned_to'] === (int) $new_assigned_to ) {
            return true;
        }

        // Only Admin can change assigned_to on an existing task
        return self::is_admin( $user );
    }

    /**
     * Check if user can delete/restore items (Admin only)
     */
    public static function can_delete_item( $user ) {
        return self::is_admin( $user );
    }

    public static function can_view_deleted( $user ) {
        return self::is_admin( $user );
    }

    public static function can_restore_item( $user ) {
        return self::is_admin( $user );
    }

    public static function can_view_admin_activity( $user ) {
        return self::is_admin( $user );
    }
}
