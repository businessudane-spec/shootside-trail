<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Auth {

    private static function get_secret_key() {
        $secret = get_option( 'shootside_pm_jwt_secret', '' );
        if ( empty( $secret ) ) {
            $secret = wp_generate_password( 64, true, true );
            update_option( 'shootside_pm_jwt_secret', $secret );
        }
        return $secret;
    }

    /**
     * Map WordPress user role to ShootSide PM role (ADMIN or MEMBER)
     */
    public static function get_user_role( $user ) {
        if ( ! $user || ! ( $user instanceof WP_User ) ) {
            return 'MEMBER';
        }
        if ( in_array( 'administrator', (array) $user->roles, true ) ) {
            return 'ADMIN';
        }
        return 'MEMBER';
    }

    /**
     * Generate secure HMAC-SHA256 signed token
     */
    public static function generate_token( $user_id ) {
        $header = base64_encode( json_encode( array( 'typ' => 'JWT', 'alg' => 'HS256' ) ) );
        $issued_at = time();
        $expire_at = $issued_at + ( DAY_IN_SECONDS * 7 ); // 7 days token lifetime

        $payload = base64_encode( json_encode( array(
            'iss' => get_bloginfo( 'url' ),
            'iat' => $issued_at,
            'exp' => $expire_at,
            'uid' => (int) $user_id
        ) ) );

        $signature = hash_hmac( 'sha256', "{$header}.{$payload}", self::get_secret_key(), true );
        $base64_url_signature = rtrim( strtr( base64_encode( $signature ), '+/', '-_' ), '=' );

        return "{$header}.{$payload}.{$base64_url_signature}";
    }

    /**
     * Validate token and return authenticated WP_User or false
     */
    public static function validate_token( $token ) {
        if ( empty( $token ) ) {
            return false;
        }

        $parts = explode( '.', $token );
        if ( count( $parts ) !== 3 ) {
            return false;
        }

        list( $header, $payload, $signature ) = $parts;

        // Verify signature
        $expected_signature = hash_hmac( 'sha256', "{$header}.{$payload}", self::get_secret_key(), true );
        $expected_base64 = rtrim( strtr( base64_encode( $expected_signature ), '+/', '-_' ), '=' );

        if ( ! hash_equals( $expected_base64, $signature ) ) {
            return false;
        }

        $decoded_payload = json_decode( base64_decode( $payload ), true );
        if ( ! $decoded_payload || ! isset( $decoded_payload['uid'], $decoded_payload['exp'] ) ) {
            return false;
        }

        if ( time() > $decoded_payload['exp'] ) {
            return false; // Token expired
        }

        $user = get_user_by( 'id', (int) $decoded_payload['uid'] );
        return ( $user && $user->exists() ) ? $user : false;
    }

    /**
     * Extract token from request Authorization header or Cookie
     */
    public static function get_current_user_from_request( $request = null ) {
        $auth_header = '';
        if ( $request && method_exists( $request, 'get_header' ) ) {
            $auth_header = $request->get_header( 'authorization' );
        }
        if ( empty( $auth_header ) && isset( $_SERVER['HTTP_AUTHORIZATION'] ) ) {
            $auth_header = $_SERVER['HTTP_AUTHORIZATION'];
        }

        if ( ! empty( $auth_header ) && preg_match( '/Bearer\s+(\S+)/i', $auth_header, $matches ) ) {
            return self::validate_token( $matches[1] );
        }

        // Check standard WP logged in user if cookie session is present
        if ( is_user_logged_in() ) {
            return wp_get_current_user();
        }

        return false;
    }

    /**
     * Format WP User object for PM API
     */
    public static function format_user( $user ) {
        if ( ! $user ) {
            return null;
        }
        if ( is_numeric( $user ) ) {
            $user = get_user_by( 'id', (int) $user );
        }
        if ( ! ( $user instanceof WP_User ) || ! $user->exists() ) {
            return null;
        }

        $avatar_url = get_avatar_url( $user->ID, array( 'size' => 128 ) );

        return array(
            'id'           => (int) $user->ID,
            'name'         => ! empty( $user->display_name ) ? $user->display_name : $user->user_login,
            'username'     => $user->user_login,
            'email'        => $user->user_email,
            'avatar'       => $avatar_url,
            'role'         => self::get_user_role( $user ),
            'registered_at'=> $user->user_registered,
            'status'       => 'active'
        );
    }

    /**
     * Get all synchronized WordPress users for Project Management
     */
    public static function get_all_users() {
        $wp_users = get_users( array(
            'orderby' => 'display_name',
            'order'   => 'ASC'
        ) );

        $users = array();
        foreach ( $wp_users as $user ) {
            $formatted = self::format_user( $user );
            if ( $formatted ) {
                $users[] = $formatted;
            }
        }
        return $users;
    }
}
