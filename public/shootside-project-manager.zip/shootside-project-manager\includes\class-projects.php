<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Projects {

    public static function format_project( $row, $include_details = true ) {
        if ( ! $row ) {
            return null;
        }

        $project_id = (int) $row['id'];
        $pm_user = ShootSide_PM_Auth::format_user( $row['project_manager_id'] );
        $creator = ShootSide_PM_Auth::format_user( $row['created_by'] );

        $members = array();
        $task_stats = array(
            'total'       => 0,
            'completed'   => 0,
            'in_progress' => 0,
            'review'      => 0,
            'todo'        => 0,
            'on_hold'     => 0
        );

        if ( $include_details ) {
            // Get members
            global $wpdb;
            $table_members = ShootSide_PM_Database::get_table_name( 'project_members' );
            $member_ids = $wpdb->get_col( $wpdb->prepare( "SELECT user_id FROM {$table_members} WHERE project_id = %d", $project_id ) );
            foreach ( (array) $member_ids as $uid ) {
                $u = ShootSide_PM_Auth::format_user( $uid );
                if ( $u ) {
                    $members[] = $u;
                }
            }

            // Get task statistics
            $table_tasks = ShootSide_PM_Database::get_table_name( 'tasks' );
            $stats_rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT status, COUNT(*) as count FROM {$table_tasks} WHERE project_id = %d AND deleted_at IS NULL GROUP BY status",
                $project_id
            ), ARRAY_A );

            foreach ( (array) $stats_rows as $sr ) {
                $st = strtolower( str_replace( ' ', '_', $sr['status'] ) );
                $cnt = (int) $sr['count'];
                $task_stats['total'] += $cnt;
                if ( isset( $task_stats[$st] ) ) {
                    $task_stats[$st] = $cnt;
                }
            }
        }

        return array(
            'id'                 => $project_id,
            'project_name'       => $row['project_name'],
            'client_name'        => $row['client_name'],
            'description'        => $row['description'],
            'start_date'         => $row['start_date'],
            'deadline'           => $row['deadline'],
            'project_manager'    => $pm_user,
            'project_manager_id' => (int) $row['project_manager_id'],
            'status'             => $row['status'],
            'priority'           => $row['priority'],
            'progress'           => (int) $row['progress'],
            'created_by'         => $creator,
            'created_by_id'      => (int) $row['created_by'],
            'members'            => $members,
            'task_stats'         => $task_stats,
            'created_at'         => $row['created_at'],
            'updated_at'         => $row['updated_at'],
            'deleted_at'         => $row['deleted_at']
        );
    }

    public static function get_all( $args = array(), $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );

        $where = array();
        $params = array();

        // Soft delete check: only admin can see deleted items if requested
        $include_deleted = ! empty( $args['deleted'] ) && ShootSide_PM_Permissions::is_admin( $current_user );
        if ( $include_deleted ) {
            $where[] = "deleted_at IS NOT NULL";
        } else {
            $where[] = "deleted_at IS NULL";
        }

        if ( ! empty( $args['status'] ) ) {
            $where[] = "status = %s";
            $params[] = $args['status'];
        }

        if ( ! empty( $args['priority'] ) ) {
            $where[] = "priority = %s";
            $params[] = $args['priority'];
        }

        if ( ! empty( $args['search'] ) ) {
            $where[] = "(project_name LIKE %s OR client_name LIKE %s OR description LIKE %s)";
            $like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $params[] = $like;
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at DESC";

        if ( ! empty( $params ) ) {
            $rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        } else {
            $rows = $wpdb->get_results( $sql, ARRAY_A );
        }

        $projects = array();
        foreach ( (array) $rows as $row ) {
            $projects[] = self::format_project( $row, true );
        }

        return $projects;
    }

    public static function get_by_id( $id, $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );
        if ( ! $row ) {
            return null;
        }

        // If soft deleted and user is not admin, deny
        if ( ! empty( $row['deleted_at'] ) && ! ShootSide_PM_Permissions::is_admin( $current_user ) ) {
            return null;
        }

        return self::format_project( $row, true );
    }

    public static function create( $data, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_create_project( $current_user ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can create projects.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );

        $insert_data = array(
            'project_name'       => sanitize_text_field( $data['project_name'] ),
            'client_name'        => isset( $data['client_name'] ) ? sanitize_text_field( $data['client_name'] ) : '',
            'description'        => isset( $data['description'] ) ? wp_kses_post( $data['description'] ) : '',
            'start_date'         => ! empty( $data['start_date'] ) ? sanitize_text_field( $data['start_date'] ) : null,
            'deadline'           => ! empty( $data['deadline'] ) ? sanitize_text_field( $data['deadline'] ) : null,
            'project_manager_id' => ! empty( $data['project_manager_id'] ) ? (int) $data['project_manager_id'] : $current_user->ID,
            'status'             => ! empty( $data['status'] ) ? sanitize_text_field( $data['status'] ) : 'Active',
            'priority'           => ! empty( $data['priority'] ) ? sanitize_text_field( $data['priority'] ) : 'Medium',
            'progress'           => isset( $data['progress'] ) ? min( 100, max( 0, (int) $data['progress'] ) ) : 0,
            'created_by'         => (int) $current_user->ID,
            'created_at'         => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $project_id = $wpdb->insert_id;

        if ( ! $project_id ) {
            return new WP_Error( 'db_error', 'Failed to create project.', array( 'status' => 500 ) );
        }

        // Set members
        if ( ! empty( $data['members'] ) && is_array( $data['members'] ) ) {
            self::set_members( $project_id, $data['members'] );
        }

        // Log activity
        ShootSide_PM_Activity::log(
            $current_user->ID,
            'project',
            $project_id,
            'created',
            null,
            $insert_data['project_name'],
            array( 'client' => $insert_data['client_name'], 'priority' => $insert_data['priority'] )
        );

        // Notify Project Manager if assigned
        if ( $insert_data['project_manager_id'] && (int) $insert_data['project_manager_id'] !== (int) $current_user->ID ) {
            ShootSide_PM_Notifications::create(
                $insert_data['project_manager_id'],
                'project_assigned',
                'Assigned as Project Manager',
                "You have been assigned as Project Manager for '{$insert_data['project_name']}'.",
                'project',
                $project_id
            );
        }

        return self::get_by_id( $project_id, $current_user );
    }

    public static function update( $id, $data, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_manage_project( $current_user, $id ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can edit projects.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );
        $old_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );

        if ( ! $old_row ) {
            return new WP_Error( 'not_found', 'Project not found.', array( 'status' => 404 ) );
        }

        $update_data = array();
        $fields = array( 'project_name', 'client_name', 'description', 'start_date', 'deadline', 'project_manager_id', 'status', 'priority', 'progress' );

        foreach ( $fields as $f ) {
            if ( isset( $data[$f] ) ) {
                if ( $f === 'description' ) {
                    $update_data[$f] = wp_kses_post( $data[$f] );
                } elseif ( in_array( $f, array( 'project_manager_id', 'progress' ), true ) ) {
                    $update_data[$f] = (int) $data[$f];
                } else {
                    $update_data[$f] = sanitize_text_field( $data[$f] );
                }
            }
        }

        if ( ! empty( $update_data ) ) {
            $wpdb->update( $table, $update_data, array( 'id' => (int) $id ) );

            // Audit log changes
            foreach ( $update_data as $key => $val ) {
                if ( isset( $old_row[$key] ) && (string) $old_row[$key] !== (string) $val ) {
                    ShootSide_PM_Activity::log(
                        $current_user->ID,
                        'project',
                        $id,
                        "updated_{$key}",
                        $old_row[$key],
                        $val
                    );
                }
            }
        }

        if ( isset( $data['members'] ) && is_array( $data['members'] ) ) {
            self::set_members( $id, $data['members'] );
        }

        return self::get_by_id( $id, $current_user );
    }

    public static function set_members( $project_id, $user_ids ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'project_members' );
        $wpdb->delete( $table, array( 'project_id' => (int) $project_id ) );

        foreach ( (array) $user_ids as $uid ) {
            $uid = (int) ( is_array( $uid ) ? ( isset( $uid['id'] ) ? $uid['id'] : 0 ) : $uid );
            if ( $uid > 0 ) {
                $wpdb->insert( $table, array(
                    'project_id' => (int) $project_id,
                    'user_id'    => $uid,
                    'created_at' => current_time( 'mysql' )
                ) );
            }
        }
    }

    public static function soft_delete( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_delete_item( $current_user ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can delete projects.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );
        $project = self::get_by_id( $id, $current_user );

        if ( ! $project ) {
            return new WP_Error( 'not_found', 'Project not found.', array( 'status' => 404 ) );
        }

        $now = current_time( 'mysql' );
        $wpdb->update( $table, array( 'deleted_at' => $now ), array( 'id' => (int) $id ) );

        // Soft delete associated tasks
        $table_tasks = ShootSide_PM_Database::get_table_name( 'tasks' );
        $wpdb->update( $table_tasks, array( 'deleted_at' => $now ), array( 'project_id' => (int) $id, 'deleted_at' => null ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'project',
            $id,
            'deleted',
            $project['project_name'],
            'deleted'
        );

        return true;
    }

    public static function restore( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_restore_item( $current_user ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can restore projects.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'projects' );
        $wpdb->update( $table, array( 'deleted_at' => null ), array( 'id' => (int) $id ) );

        // Restore associated tasks
        $table_tasks = ShootSide_PM_Database::get_table_name( 'tasks' );
        $wpdb->update( $table_tasks, array( 'deleted_at' => null ), array( 'project_id' => (int) $id ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'project',
            $id,
            'restored',
            'deleted',
            'active'
        );

        return self::get_by_id( $id, $current_user );
    }
}
