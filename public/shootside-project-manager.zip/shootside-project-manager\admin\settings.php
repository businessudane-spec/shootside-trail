<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Settings {

    public function __construct() {
        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
    }

    public function register_menu() {
        add_menu_page(
            'ShootSide PM',
            'ShootSide PM',
            'manage_options',
            'shootside-pm-settings',
            array( $this, 'render_settings_page' ),
            'dashicons-portfolio',
            30
        );
    }

    public function register_settings() {
        register_setting( 'shootside_pm_options_group', 'shootside_pm_allowed_origins' );
        register_setting( 'shootside_pm_options_group', 'shootside_pm_jwt_secret' );
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        if ( isset( $_POST['shootside_pm_run_db_migration'] ) && check_admin_referer( 'shootside_pm_migration_nonce' ) ) {
            ShootSide_PM_Database::migrate();
            echo '<div class="notice notice-success is-dismissible"><p><strong>Database tables verified and updated successfully.</strong></p></div>';
        }

        $allowed_origins = get_option( 'shootside_pm_allowed_origins', "http://localhost:3000\nhttp://localhost:3001\nhttps://shootside.in\nhttps://*.vercel.app" );
        $jwt_secret      = get_option( 'shootside_pm_jwt_secret', '' );
        ?>
        <div class="wrap">
            <h1>ShootSide Project Manager - Backend Settings</h1>
            <p style="color: #666;">REST API Root: <code><?php echo esc_url( rest_url( SHOOTSIDE_PM_API_NAMESPACE ) ); ?></code></p>

            <form method="post" action="options.php" style="max-width: 800px; background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ccd0d4; margin-top: 15px;">
                <?php settings_fields( 'shootside_pm_options_group' ); ?>
                <?php do_settings_sections( 'shootside_pm_options_group' ); ?>

                <table class="form-table">
                    <tr valign="top">
                        <th scope="row"><strong>Allowed CORS Origins</strong><br><small>One URL per line. Wildcards like <code>https://*.vercel.app</code> supported.</small></th>
                        <td>
                            <textarea name="shootside_pm_allowed_origins" rows="6" style="width: 100%; font-family: monospace;"><?php echo esc_textarea( $allowed_origins ); ?></textarea>
                            <p class="description">Allow your Next.js / Vercel frontend domain to make authenticated requests.</p>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row"><strong>JWT Secret Key</strong><br><small>HMAC-SHA256 Token Signature</small></th>
                        <td>
                            <input type="text" name="shootside_pm_jwt_secret" value="<?php echo esc_attr( $jwt_secret ); ?>" style="width: 100%; font-family: monospace;" />
                            <p class="description">Leave blank to auto-generate a cryptographically secure 64-character secret key.</p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( 'Save Settings' ); ?>
            </form>

            <div style="max-width: 800px; background: #fff; padding: 20px; border-radius: 8px; border: 1px solid #ccd0d4; margin-top: 25px;">
                <h3>System Status & Database Tables</h3>
                <p>Verify that all custom Project Management MariaDB tables exist in the current WordPress database.</p>
                
                <form method="post" action="">
                    <?php wp_nonce_field( 'shootside_pm_migration_nonce' ); ?>
                    <input type="hidden" name="shootside_pm_run_db_migration" value="1" />
                    <button type="submit" class="button button-secondary">Run / Verify Database Schema (dbDelta)</button>
                </form>

                <ul style="margin-top: 15px; font-family: monospace; color: #444;">
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'projects' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'project_members' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'tasks' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'comments' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'attachments' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'activity' ) ); ?></li>
                    <li>✓ <?php echo esc_html( ShootSide_PM_Database::get_table_name( 'notifications' ) ); ?></li>
                </ul>
            </div>
        </div>
        <?php
    }
}

new ShootSide_PM_Settings();
