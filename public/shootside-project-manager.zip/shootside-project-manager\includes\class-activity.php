<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Activity {

    public static function log( $user_id, $entity_type, $entity_id, $action, $old_value = null, $new_value = null, $metadata = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'activity' );

        $data = array(
            'user_id'     => (int) $user_id,
            'entity_type' => sanitize_text_field( $entity_type ),
            'entity_id'   => (int) $entity_id,
            'action'      => sanitize_text_field( $action ),
            'old_value'   => is_array( $old_value ) || is_object( $old_value ) ? json_encode( $old_value ) : (string) $old_value,
            'new_value'   => is_array( $new_value ) || is_object( $new_value ) ? json_encode( $new_value ) : (string) $new_value,
            'metadata'    => is_array( $metadata ) || is_object( $metadata ) ? json_encode( $metadata ) : (string) $metadata,
            'created_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function get_activities( $args = array() ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'activity' );

        $where = array( "1=1" );
        $params = array();

        if ( ! empty( $args['entity_type'] ) ) {
            $where[] = "entity_type = %s";
            $params[] = $args['entity_type'];
        }

        if ( ! empty( $args['entity_id'] ) ) {
            $where[] = "entity_id = %d";
            $params[] = (int) $args['entity_id'];
        }

        if ( ! empty( $args['user_id'] ) ) {
            $where[] = "user_id = %d";
            $params[] = (int) $args['user_id'];
        }

        if ( ! empty( $args['action'] ) ) {
            $where[] = "action = %s";
            $params[] = $args['action'];
        }

        if ( ! empty( $args['date_from'] ) ) {
            $where[] = "created_at >= %s";
            $params[] = $args['date_from'];
        }

        if ( ! empty( $args['date_to'] ) ) {
            $where[] = "created_at <= %s";
            $params[] = $args['date_to'] . ' 23:59:59';
        }

        $where_sql = implode( ' AND ', $where );
        $limit = isset( $args['limit'] ) ? (int) $args['limit'] : 100;
        $offset = isset( $args['offset'] ) ? (int) $args['offset'] : 0;

        $sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at DESC LIMIT {$limit} OFFSET {$offset}";

        if ( ! empty( $params ) ) {
            $results = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        } else {
            $results = $wpdb->get_results( $sql, ARRAY_A );
        }

        $formatted = array();
        foreach ( (array) $results as $row ) {
            $user = ShootSide_PM_Auth::format_user( $row['user_id'] );
            $row['user_name'] = $user ? $user['name'] : 'System';
            $row['user_avatar'] = $user ? $user['avatar'] : '';
            $row['user_role'] = $user ? $user['role'] : '';
            $formatted[] = $row;
        }

        return $formatted;
    }
}
