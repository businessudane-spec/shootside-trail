# ShootSide Project Manager - WordPress Plugin

Custom REST API & MariaDB persistence backend for ShootSide Internal Project & Task Management System.

## Features
- **Headless WordPress REST API**: Namespaced under `/wp-json/shootside-pm/v1/`.
- **Zero WordPress Disruption**: Operates entirely in custom tables prefixed with dynamic `$wpdb->prefix`.
- **JWT Authentication**: Authenticates with existing WordPress credentials and issues HMAC-SHA256 signed bearer tokens.
- **Strict Role Enforcement**:
  - `ADMIN`: Full access (Create/Edit/Delete/Restore projects and tasks, Reassign tasks, Admin audit log, Trash management).
  - `MEMBER`: Collaborative task creation and updates. **Cannot reassign existing tasks**.
- **Immutable Audit Trail**: Tracks all changes with old and new values.
- **Soft Delete & Recovery**: Deleted projects and tasks remain safe and restorable.
- **In-App Notifications**: Real-time notifications for task assignments, comments, and status updates.

## Installation on WordPress (shootside.in)
1. Compress the `shootside-project-manager` directory into a `.zip` archive.
2. In WordPress Admin, go to **Plugins** -> **Add New** -> **Upload Plugin**.
3. Select `shootside-project-manager.zip` and click **Install Now**, then **Activate**.
4. Go to the new menu **ShootSide PM** in WordPress admin to review Allowed CORS Origins and database status.
