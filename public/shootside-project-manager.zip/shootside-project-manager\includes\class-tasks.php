<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Tasks {

    public static function format_task( $row, $include_details = true ) {
        if ( ! $row ) {
            return null;
        }

        $task_id = (int) $row['id'];
        $assignee = ShootSide_PM_Auth::format_user( $row['assigned_to'] );
        $creator = ShootSide_PM_Auth::format_user( $row['created_by'] );

        // Project brief info
        global $wpdb;
        $table_projects = ShootSide_PM_Database::get_table_name( 'projects' );
        $project_row = $wpdb->get_row( $wpdb->prepare( "SELECT id, project_name, client_name, status FROM {$table_projects} WHERE id = %d", (int) $row['project_id'] ), ARRAY_A );

        $comments_count = 0;
        $attachments_count = 0;

        if ( $include_details ) {
            $table_comments = ShootSide_PM_Database::get_table_name( 'comments' );
            $comments_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_comments} WHERE task_id = %d AND deleted_at IS NULL", $task_id ) );

            $table_attachments = ShootSide_PM_Database::get_table_name( 'attachments' );
            $attachments_count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table_attachments} WHERE task_id = %d", $task_id ) );
        }

        return array(
            'id'                => $task_id,
            'project_id'        => (int) $row['project_id'],
            'project_name'      => $project_row ? $project_row['project_name'] : 'Unknown Project',
            'client_name'       => $project_row ? $project_row['client_name'] : '',
            'title'             => $row['title'],
            'description'       => $row['description'],
            'assigned_to'       => $assignee,
            'assigned_to_id'    => (int) $row['assigned_to'],
            'created_by'        => $creator,
            'created_by_id'     => (int) $row['created_by'],
            'status'            => $row['status'],
            'priority'          => $row['priority'],
            'start_date'        => $row['start_date'],
            'due_date'          => $row['due_date'],
            'estimated_hours'   => (float) $row['estimated_hours'],
            'actual_hours'      => (float) $row['actual_hours'],
            'progress'          => (int) $row['progress'],
            'comments_count'    => $comments_count,
            'attachments_count' => $attachments_count,
            'created_at'        => $row['created_at'],
            'updated_at'        => $row['updated_at'],
            'deleted_at'        => $row['deleted_at']
        );
    }

    public static function get_all( $args = array(), $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );

        $where = array();
        $params = array();

        $include_deleted = ! empty( $args['deleted'] ) && ShootSide_PM_Permissions::is_admin( $current_user );
        if ( $include_deleted ) {
            $where[] = "deleted_at IS NOT NULL";
        } else {
            $where[] = "deleted_at IS NULL";
        }

        if ( ! empty( $args['project_id'] ) ) {
            $where[] = "project_id = %d";
            $params[] = (int) $args['project_id'];
        }

        if ( ! empty( $args['assigned_to'] ) ) {
            $where[] = "assigned_to = %d";
            $params[] = (int) $args['assigned_to'];
        }

        if ( ! empty( $args['status'] ) ) {
            $where[] = "status = %s";
            $params[] = $args['status'];
        }

        if ( ! empty( $args['priority'] ) ) {
            $where[] = "priority = %s";
            $params[] = $args['priority'];
        }

        if ( ! empty( $args['search'] ) ) {
            $where[] = "(title LIKE %s OR description LIKE %s)";
            $like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $params[] = $like;
            $params[] = $like;
        }

        $where_sql = implode( ' AND ', $where );
        $order_by = "ORDER BY FIELD(priority, 'Urgent', 'High', 'Medium', 'Low'), due_date ASC, created_at DESC";

        $sql = "SELECT * FROM {$table} WHERE {$where_sql} {$order_by}";

        if ( ! empty( $params ) ) {
            $rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
        } else {
            $rows = $wpdb->get_results( $sql, ARRAY_A );
        }

        $tasks = array();
        foreach ( (array) $rows as $row ) {
            $tasks[] = self::format_task( $row, true );
        }

        return $tasks;
    }

    public static function get_by_id( $id, $current_user = null ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );
        if ( ! $row ) {
            return null;
        }

        if ( ! empty( $row['deleted_at'] ) && ! ShootSide_PM_Permissions::is_admin( $current_user ) ) {
            return null;
        }

        return self::format_task( $row, true );
    }

    public static function create( $data, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_create_task( $current_user ) ) {
            return new WP_Error( 'unauthorized', 'Authentication required.', array( 'status' => 401 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );

        $project_id = isset( $data['project_id'] ) ? (int) $data['project_id'] : 0;
        if ( ! $project_id ) {
            return new WP_Error( 'missing_field', 'Project ID is required.', array( 'status' => 400 ) );
        }

        $assigned_to = ! empty( $data['assigned_to'] ) ? (int) $data['assigned_to'] : 0;

        $insert_data = array(
            'project_id'      => $project_id,
            'title'           => sanitize_text_field( $data['title'] ),
            'description'     => isset( $data['description'] ) ? wp_kses_post( $data['description'] ) : '',
            'assigned_to'     => $assigned_to,
            'created_by'      => (int) $current_user->ID,
            'status'          => ! empty( $data['status'] ) ? sanitize_text_field( $data['status'] ) : 'To Do',
            'priority'        => ! empty( $data['priority'] ) ? sanitize_text_field( $data['priority'] ) : 'Medium',
            'start_date'      => ! empty( $data['start_date'] ) ? sanitize_text_field( $data['start_date'] ) : null,
            'due_date'        => ! empty( $data['due_date'] ) ? sanitize_text_field( $data['due_date'] ) : null,
            'estimated_hours' => isset( $data['estimated_hours'] ) ? (float) $data['estimated_hours'] : 0.00,
            'actual_hours'    => isset( $data['actual_hours'] ) ? (float) $data['actual_hours'] : 0.00,
            'progress'        => isset( $data['progress'] ) ? min( 100, max( 0, (int) $data['progress'] ) ) : 0,
            'created_at'      => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $insert_data );
        $task_id = $wpdb->insert_id;

        if ( ! $task_id ) {
            return new WP_Error( 'db_error', 'Failed to create task.', array( 'status' => 500 ) );
        }

        // Activity log
        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $task_id,
            'created',
            null,
            $insert_data['title'],
            array( 'project_id' => $project_id, 'status' => $insert_data['status'], 'priority' => $insert_data['priority'] )
        );

        // Notification for assigned user
        if ( $assigned_to && (int) $assigned_to !== (int) $current_user->ID ) {
            $creator_name = $current_user->display_name ?: $current_user->user_login;
            ShootSide_PM_Notifications::create(
                $assigned_to,
                'task_assigned',
                'New Task Assigned',
                "{$creator_name} assigned you a new task: '{$insert_data['title']}'.",
                'task',
                $task_id
            );
        }

        return self::get_by_id( $task_id, $current_user );
    }

    public static function update( $id, $data, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_edit_task( $current_user, $id ) ) {
            return new WP_Error( 'unauthorized', 'Permission denied.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );
        $old_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ), ARRAY_A );

        if ( ! $old_row ) {
            return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) );
        }

        // STRICT REASSIGNMENT CHECK: Only Admin can reassign existing tasks
        if ( isset( $data['assigned_to'] ) && (int) $data['assigned_to'] !== (int) $old_row['assigned_to'] ) {
            if ( ! ShootSide_PM_Permissions::can_reassign_task( $current_user, $old_row, $data['assigned_to'] ) ) {
                return new WP_Error( 'forbidden', 'Only Administrators can reassign existing tasks.', array( 'status' => 403 ) );
            }
        }

        $update_data = array();
        $fields = array( 'title', 'description', 'status', 'priority', 'start_date', 'due_date', 'estimated_hours', 'actual_hours', 'progress' );

        // If admin permitted to change assignee
        if ( isset( $data['assigned_to'] ) && ShootSide_PM_Permissions::can_reassign_task( $current_user, $old_row, $data['assigned_to'] ) ) {
            $update_data['assigned_to'] = (int) $data['assigned_to'];
        }

        foreach ( $fields as $f ) {
            if ( isset( $data[$f] ) ) {
                if ( $f === 'description' ) {
                    $update_data[$f] = wp_kses_post( $data[$f] );
                } elseif ( in_array( $f, array( 'progress' ), true ) ) {
                    $update_data[$f] = min( 100, max( 0, (int) $data[$f] ) );
                } elseif ( in_array( $f, array( 'estimated_hours', 'actual_hours' ), true ) ) {
                    $update_data[$f] = (float) $data[$f];
                } else {
                    $update_data[$f] = sanitize_text_field( $data[$f] );
                }
            }
        }

        if ( ! empty( $update_data ) ) {
            $wpdb->update( $table, $update_data, array( 'id' => (int) $id ) );

            // Audit log changes with old and new values
            foreach ( $update_data as $key => $val ) {
                if ( isset( $old_row[$key] ) && (string) $old_row[$key] !== (string) $val ) {
                    $action_name = "updated_{$key}";
                    $old_disp = $old_row[$key];
                    $new_disp = $val;

                    if ( $key === 'assigned_to' ) {
                        $action_name = 'reassigned';
                        $old_u = ShootSide_PM_Auth::format_user( $old_disp );
                        $new_u = ShootSide_PM_Auth::format_user( $new_disp );
                        $old_disp = $old_u ? $old_u['name'] : "User #{$old_disp}";
                        $new_disp = $new_u ? $new_u['name'] : "User #{$new_disp}";

                        // Notify newly assigned user
                        if ( (int) $val !== (int) $current_user->ID ) {
                            ShootSide_PM_Notifications::create(
                                (int) $val,
                                'task_reassigned',
                                'Task Reassigned to You',
                                "Admin reassigned task '{$old_row['title']}' to you.",
                                'task',
                                $id
                            );
                        }
                    } elseif ( $key === 'status' ) {
                        $action_name = 'status_changed';
                        // Notify creator/assignee if someone else changed status
                        if ( (int) $old_row['assigned_to'] !== (int) $current_user->ID && (int) $old_row['assigned_to'] > 0 ) {
                            ShootSide_PM_Notifications::create(
                                (int) $old_row['assigned_to'],
                                'status_changed',
                                'Task Status Updated',
                                "Status of '{$old_row['title']}' changed from {$old_disp} to {$new_disp}.",
                                'task',
                                $id
                            );
                        }
                    }

                    ShootSide_PM_Activity::log(
                        $current_user->ID,
                        'task',
                        $id,
                        $action_name,
                        $old_disp,
                        $new_disp,
                        array( 'task_title' => $old_row['title'] )
                    );
                }
            }
        }

        return self::get_by_id( $id, $current_user );
    }

    public static function soft_delete( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_delete_item( $current_user ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can delete tasks.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );
        $task = self::get_by_id( $id, $current_user );

        if ( ! $task ) {
            return new WP_Error( 'not_found', 'Task not found.', array( 'status' => 404 ) );
        }

        $now = current_time( 'mysql' );
        $wpdb->update( $table, array( 'deleted_at' => $now ), array( 'id' => (int) $id ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $id,
            'deleted',
            $task['title'],
            'deleted'
        );

        return true;
    }

    public static function restore( $id, $current_user ) {
        if ( ! ShootSide_PM_Permissions::can_restore_item( $current_user ) ) {
            return new WP_Error( 'forbidden', 'Only Administrators can restore tasks.', array( 'status' => 403 ) );
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'tasks' );
        $wpdb->update( $table, array( 'deleted_at' => null ), array( 'id' => (int) $id ) );

        ShootSide_PM_Activity::log(
            $current_user->ID,
            'task',
            $id,
            'restored',
            'deleted',
            'active'
        );

        return self::get_by_id( $id, $current_user );
    }
}
