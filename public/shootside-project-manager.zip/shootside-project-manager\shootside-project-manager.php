<?php
/**
 * Plugin Name:       ShootSide Project Manager
 * Plugin URI:        https://shootside.in/
 * Description:       Enterprise-grade Internal Project & Task Management Backend REST API for ShootSide.
 * Version:           1.0.0
 * Author:            ShootSide Engineering
 * Author URI:        https://shootside.in/
 * License:           GPL-2.0+
 * Text Domain:       shootside-pm
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

define( 'SHOOTSIDE_PM_VERSION', '1.0.0' );
define( 'SHOOTSIDE_PM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SHOOTSIDE_PM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'SHOOTSIDE_PM_API_NAMESPACE', 'shootside-pm/v1' );

// Require all core classes
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-database.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-auth.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-permissions.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-activity.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-notifications.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-projects.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-tasks.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-comments.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-attachments.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'includes/class-api.php';
require_once SHOOTSIDE_PM_PLUGIN_DIR . 'admin/settings.php';

/**
 * Main Plugin Class
 */
final class ShootSide_Project_Manager {

    private static $instance = null;

    public static function instance() {
        if ( is_null( self::$instance ) ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        // Register activation hook for database migrations
        register_activation_hook( __FILE__, array( 'ShootSide_PM_Database', 'migrate' ) );

        // Initialize REST API and CORS
        add_action( 'rest_api_init', array( $this, 'init_rest_api' ) );
        add_action( 'init', array( $this, 'handle_cors' ), 1 );
    }

    public function init_rest_api() {
        $api = new ShootSide_PM_API();
        $api->register_routes();
    }

    /**
     * Configure Secure CORS for React / Vercel frontend
     */
    public function handle_cors() {
        $allowed_origins = get_option( 'shootside_pm_allowed_origins', "http://localhost:3000\nhttp://localhost:3001\nhttps://shootside.in\nhttps://*.vercel.app" );
        $origins_array   = array_filter( array_map( 'trim', explode( "\n", str_replace( "\r", "", $allowed_origins ) ) ) );

        $origin = isset( $_SERVER['HTTP_ORIGIN'] ) ? $_SERVER['HTTP_ORIGIN'] : '';

        if ( ! empty( $origin ) ) {
            $is_allowed = false;
            foreach ( $origins_array as $allowed ) {
                if ( $allowed === '*' || $origin === $allowed ) {
                    $is_allowed = true;
                    break;
                }
                // Support wildcard matching for *.vercel.app
                if ( strpos( $allowed, '*' ) !== false ) {
                    $pattern = '#^' . str_replace( '\*', '.*', preg_quote( $allowed, '#' ) ) . '$#i';
                    if ( preg_match( $pattern, $origin ) ) {
                        $is_allowed = true;
                        break;
                    }
                }
            }

            if ( $is_allowed ) {
                header( "Access-Control-Allow-Origin: {$origin}" );
                header( 'Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS' );
                header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-Requested-With' );
                header( 'Access-Control-Allow-Credentials: true' );
                header( 'Access-Control-Max-Age: 86400' );
            }
        }

        // Handle preflight OPTIONS request
        if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {
            status_header( 200 );
            exit;
        }
    }
}

// Initialize plugin
ShootSide_Project_Manager::instance();
