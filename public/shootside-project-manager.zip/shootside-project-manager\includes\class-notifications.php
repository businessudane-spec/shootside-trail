<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ShootSide_PM_Notifications {

    public static function create( $user_id, $type, $title, $message, $entity_type = '', $entity_id = 0 ) {
        if ( empty( $user_id ) ) {
            return false;
        }

        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'notifications' );

        $data = array(
            'user_id'     => (int) $user_id,
            'type'        => sanitize_text_field( $type ),
            'title'       => sanitize_text_field( $title ),
            'message'     => sanitize_textarea_field( $message ),
            'entity_type' => sanitize_text_field( $entity_type ),
            'entity_id'   => (int) $entity_id,
            'is_read'     => 0,
            'created_at'  => current_time( 'mysql' )
        );

        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function get_for_user( $user_id, $unread_only = false, $limit = 50 ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'notifications' );

        $where = "user_id = %d";
        if ( $unread_only ) {
            $where .= " AND is_read = 0";
        }

        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where} ORDER BY created_at DESC LIMIT %d", (int) $user_id, (int) $limit );
        return $wpdb->get_results( $sql, ARRAY_A );
    }

    public static function get_unread_count( $user_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'notifications' );
        $count = $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0", (int) $user_id ) );
        return (int) $count;
    }

    public static function mark_as_read( $notification_id, $user_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'notifications' );
        return $wpdb->update(
            $table,
            array( 'is_read' => 1 ),
            array( 'id' => (int) $notification_id, 'user_id' => (int) $user_id ),
            array( '%d' ),
            array( '%d', '%d' )
        );
    }

    public static function mark_all_as_read( $user_id ) {
        global $wpdb;
        $table = ShootSide_PM_Database::get_table_name( 'notifications' );
        return $wpdb->update(
            $table,
            array( 'is_read' => 1 ),
            array( 'user_id' => (int) $user_id ),
            array( '%d' ),
            array( '%d' )
        );
    }
}
